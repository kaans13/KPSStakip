# KPSS Takip — Dağıtım Rehberi

## Yöntem 1: EXE (Önerilen — Python gerekmez)

### Tek seferlik kurulum adımları

1. **Python 3.9+ kur** (sadece build için)
   - https://www.python.org/downloads/
   - Kurulumda "Add Python to PATH" kutusunu işaretle

2. **Proje klasörüne git** (kpss_tracker klasörü)

3. **Build script'i çalıştır:**
   ```
   build_windows.bat
   ```
   - Script otomatik olarak paketleri kurar ve EXE'yi oluşturur
   - İlk seferinde ~3-5 dakika sürer
   - `dist\KPSS_Takip.exe` oluşur

4. **Dağıt:**
   - Sadece `dist\KPSS_Takip.exe` dosyasını paylaş
   - Kullanıcı çift tıklar, çalışır — başka kurulum yok

### Notlar
- EXE boyutu ~80-120 MB olur (Python + tüm kütüphaneler içinde)
- İlk açılış 3-5 saniye sürebilir (normal)
- Kullanıcı verisi (DB) exe'nin yanında `kpss_data/` klasöründe tutulur
- Taşınabilir: klasörü kopyalayıp USB'de de çalışır

---

## Yöntem 2: Installer (kurulum sihirbazı)

Daha profesyonel görünüm için Inno Setup kullan:

1. **Inno Setup kur:** https://jrsoftware.org/isinfo.php

2. `installer.iss` dosyasını Inno Setup ile derle

3. Tek `KPSS_Takip_Setup.exe` kurulum dosyası çıkar

4. Kullanıcı çalıştırır → Program Files'a kurar → Masaüstüne kısayol ekler

---

## Yöntem 3: Python ile çalıştır (geliştiriciler için)

```bash
pip install customtkinter matplotlib numpy
python main.py
```

---

## Sorun Giderme

### "Windows korudu bu uygulamayı" uyarısı
→ "Daha fazla bilgi" → "Yine de çalıştır" — imzasız exe'lerde normaldir

### Antivirus engeli
→ PyInstaller exe'leri bazen yanlış pozitif verir
→ Kullanıcı antivirus dışında tutabilir veya VirusTotal'den kontrol edebilirsin

### İlk açılış yavaş
→ PyInstaller geçici klasöre açıyor, normaldir, sonraki açılışlar daha hızlı

### "missing DLL" hatası
→ Visual C++ Redistributable kur: https://aka.ms/vs/17/release/vc_redist.x64.exe
