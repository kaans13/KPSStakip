# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec dosyası — kpss_tracker
# Kullanım: pyinstaller kpss_tracker.spec

import sys
from pathlib import Path

ROOT = Path(SPECDIR)

block_cipher = None

a = Analysis(
    [str(ROOT / 'main.py')],
    pathex=[str(ROOT)],
    binaries=[],
    datas=[
        # Veri dosyaları — (kaynak, exe içindeki hedef klasör)
        (str(ROOT / 'data' / 'curriculum.json'),  'data'),
        (str(ROOT / 'database' / 'schema.sql'),   'database'),
    ],
    hiddenimports=[
        # CustomTkinter tema dosyaları
        'customtkinter',
        'customtkinter.windows',
        'customtkinter.windows.widgets',
        'customtkinter.windows.widgets.theme',
        # Matplotlib
        'matplotlib',
        'matplotlib.backends.backend_tkagg',
        'matplotlib.backends.backend_agg',
        'matplotlib.figure',
        'matplotlib.pyplot',
        # Numpy
        'numpy',
        'numpy.core._multiarray_umath',
        'numpy.core._multiarray_tests',
        # PIL (opsiyonel pystray için)
        'PIL',
        'PIL._tkinter_finder',
        # Tkinter
        'tkinter',
        'tkinter.filedialog',
        'tkinter.messagebox',
        # Standart kütüphaneler
        'sqlite3',
        'json',
        'threading',
        'calendar',
        'wave',
        'struct',
        'tempfile',
        'winsound',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Gereksiz büyük paketler — exe boyutunu küçültür
        'IPython', 'jupyter', 'notebook',
        'pytest', 'setuptools', 'pip',
        'PyQt5', 'PyQt6', 'wx',
        'scipy', 'pandas', 'sklearn',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='KPSS_Takip',           # .exe dosya adı
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,                    # UPX ile sıkıştır (varsa)
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,               # Siyah konsol penceresi AÇILMAZ
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # icon='data/logo.ico',      # Logo varsa bu satırı aç
)
