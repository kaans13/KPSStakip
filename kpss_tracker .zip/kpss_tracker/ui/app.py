"""
ui/app.py  —  v3
- database is locked FIX: panel geçişlerinde timer durdurulur
- sticky konu seçimi (son seçimi hatırla)
- tkcalendar entegrasyonu (yoksa özel grid)
- pystray sistem tepsisi
- tüm widget tanımları ayrı satırlarda
"""
from __future__ import annotations

import os
import sys
import threading
import calendar as cal_module
from datetime import date, timedelta
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import customtkinter as ctk
from database.db_manager import DatabaseManager
from modules.pomodoro import PomodoroTimer, SessionState, play_notification_sound
from modules.charts import (
    build_heatmap, build_error_chart, build_weekly_study_chart,
    build_period_bar, build_subject_bar, build_subject_radar,
    build_topic_treemap, build_accuracy_trend, build_error_breakdown_pie,
)
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

C = {
    "bg":       "#1E1E2E",
    "surface":  "#2A2A3E",
    "surface2": "#313147",
    "accent":   "#89B4FA",
    "green":    "#A6E3A1",
    "red":      "#F38BA8",
    "yellow":   "#F9E2AF",
    "mauve":    "#CBA6F7",
    "teal":     "#94E2D5",
    "text":     "#CDD6F4",
    "subtext":  "#A6ADC8",
}
SUBJ_COLORS = {
    "Tarih":       "#C8A96E",
    "Coğrafya":    "#6EAD8B",
    "Vatandaşlık": "#8B8BC8",
    "Türkçe":      "#C87A7A",
    "Matematik":   "#7AB8C8",
}


# ═══════════════════════════════════════════════════════════
# PAYLAŞILAN TIMER — uygulama boyunca tek örnek
# Panel değişiminde destroy edilmez, sadece UI referansı güncellenir
# ═══════════════════════════════════════════════════════════
class AppTimer:
    """Singleton benzeri Pomodoro timer — paneller arası kalıcı."""
    _instance: Optional["AppTimer"] = None

    @classmethod
    def get(cls, db: DatabaseManager) -> "AppTimer":
        if cls._instance is None:
            cls._instance = cls(db)
        return cls._instance

    def __init__(self, db: DatabaseManager):
        self.db = db
        w = int(db.get_setting("pomodoro_work_min",  "25"))
        s = int(db.get_setting("pomodoro_short_min", "5"))
        l = int(db.get_setting("pomodoro_long_min",  "15"))
        p = int(db.get_setting("pomodoros_per_set",  "4"))
        self.timer = PomodoroTimer(
            work_min=w, short_break_min=s, long_break_min=l,
            pomodoros_per_set=p,
            on_tick=self._on_tick,
            on_session_end=self._on_session_end,
        )
        self.active_session_id: Optional[int] = None
        self.sound_enabled  = db.get_setting("sound_enabled", "1") == "1"
        self.wav_path       = db.get_setting("sound_wav_path", "")
        # UI callback referansları — PomodoroPanel bağlandıkça güncellenir
        self.tick_cb    = None   # (remaining: int) -> None
        self.end_cb     = None   # (state: SessionState) -> None

    def _on_tick(self, remaining: int):
        if self.tick_cb:
            try:
                self.tick_cb(remaining)
            except Exception:
                pass

    def _on_session_end(self, state: SessionState):
        play_notification_sound(
            "end" if state == SessionState.WORK else "break",
            wav_path=self.wav_path or None,
            enabled=self.sound_enabled,
        )
        if state == SessionState.WORK and self.active_session_id:
            self.db.finish_pomodoro(
                self.active_session_id,
                self.timer.elapsed_minutes,
                3,  # UI gelmemişse varsayılan odak puanı
                completed=True,
            )
            self.active_session_id = None
        if self.end_cb:
            try:
                self.end_cb(state)
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════
# YARDIMCILAR
# ═══════════════════════════════════════════════════════════
class Card(ctk.CTkFrame):
    def __init__(self, master, title: str = "", **kw):
        super().__init__(master, corner_radius=12, fg_color=C["surface"], **kw)
        if title:
            lbl = ctk.CTkLabel(self, text=title,
                               font=ctk.CTkFont(size=13, weight="bold"),
                               text_color=C["text"])
            lbl.pack(anchor="w", padx=14, pady=(10, 4))


class StatBadge(ctk.CTkFrame):
    def __init__(self, master, label: str, value: str,
                 color: str = C["accent"]):
        super().__init__(master, corner_radius=8, fg_color=C["surface2"])
        self._vl = ctk.CTkLabel(self, text=value,
                                font=ctk.CTkFont(size=20, weight="bold"),
                                text_color=color)
        self._vl.pack(pady=(8, 0), padx=16)
        ctk.CTkLabel(self, text=label, font=ctk.CTkFont(size=10),
                     text_color=C["subtext"]).pack(pady=(0, 8), padx=16)

    def update(self, v: str):
        self._vl.configure(text=v)


def embed_chart(parent, fig):
    canvas = FigureCanvasTkAgg(fig, master=parent)
    canvas.draw()
    w = canvas.get_tk_widget()
    w.pack(fill="x", padx=10, pady=(0, 10))
    return canvas


def progress_row(parent, label: str, pct: float, color: str):
    row = ctk.CTkFrame(parent, fg_color="transparent")
    row.pack(fill="x", padx=14, pady=2)
    lbl = ctk.CTkLabel(row, text=label, width=140, anchor="w",
                        text_color=C["text"], font=ctk.CTkFont(size=11))
    lbl.pack(side="left")
    pb = ctk.CTkProgressBar(row, height=10, corner_radius=5,
                             progress_color=color)
    pb.pack(side="left", fill="x", expand=True, padx=8)
    pb.set(max(0.0, min(1.0, pct / 100)))
    pct_lbl = ctk.CTkLabel(row, text=f"%{round(pct)}", width=40,
                            text_color=C["subtext"],
                            font=ctk.CTkFont(size=10))
    pct_lbl.pack(side="right")


def validate_pos(val: str, name: str) -> int:
    try:
        v = int(val)
    except (ValueError, TypeError):
        raise ValueError(f"{name} sayı olmalı.")
    if v <= 0:
        raise ValueError(f"{name} sıfırdan büyük olmalı.")
    return v


def validate_nneg(val: str, name: str) -> int:
    try:
        v = int(val)
    except (ValueError, TypeError):
        raise ValueError(f"{name} sayı olmalı.")
    if v < 0:
        raise ValueError(f"{name} negatif olamaz.")
    return v


# ═══════════════════════════════════════════════════════════
# ONBOARDING
# ═══════════════════════════════════════════════════════════
class OnboardingWindow(ctk.CTkToplevel):
    def __init__(self, master, db: DatabaseManager, on_done):
        super().__init__(master)
        self.db = db
        self.on_done = on_done
        self.title("Hoş Geldin!")
        self.geometry("460x340")
        self.resizable(False, False)
        self.configure(fg_color=C["bg"])
        self.grab_set()
        self.lift()
        self._build()

    def _build(self):
        bar = ctk.CTkFrame(self, height=6, fg_color=C["accent"], corner_radius=0)
        bar.pack(fill="x")

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(expand=True, padx=44, pady=10)

        emoji_lbl = ctk.CTkLabel(body, text="🎓", font=ctk.CTkFont(size=52))
        emoji_lbl.pack(pady=(10, 4))

        title_lbl = ctk.CTkLabel(body, text="KPSS Takip Uygulaması",
                                  font=ctk.CTkFont(size=18, weight="bold"),
                                  text_color=C["text"])
        title_lbl.pack()

        sub_lbl = ctk.CTkLabel(body, text="Seni tanımak isterim. Adın ne?",
                                font=ctk.CTkFont(size=13),
                                text_color=C["subtext"])
        sub_lbl.pack(pady=(10, 12))

        self._name_entry = ctk.CTkEntry(body, width=280, height=42,
                                         placeholder_text="Adını gir...",
                                         font=ctk.CTkFont(size=14),
                                         corner_radius=10)
        self._name_entry.pack()
        self._name_entry.bind("<Return>", lambda e: self._submit())

        self._err = ctk.CTkLabel(body, text="", text_color=C["red"],
                                  font=ctk.CTkFont(size=11))
        self._err.pack(pady=(4, 0))

        start_btn = ctk.CTkButton(body, text="Hadi Başlayalım! 🚀",
                                   height=42, width=240, corner_radius=10,
                                   font=ctk.CTkFont(size=14, weight="bold"),
                                   fg_color=C["accent"], text_color="#1E1E2E",
                                   hover_color="#6fa3f7",
                                   command=self._submit)
        start_btn.pack(pady=(12, 0))
        self.after(200, self._name_entry.focus)

    def _submit(self):
        name = self._name_entry.get().strip()
        if not name:
            self._err.configure(text="Lütfen adını gir.")
            return
        self.db.complete_onboarding(name)
        self.destroy()
        self.on_done()


# ═══════════════════════════════════════════════════════════
# PANEL: DASHBOARD
# ═══════════════════════════════════════════════════════════
class DashboardPanel(ctk.CTkScrollableFrame):
    def __init__(self, master, db: DatabaseManager):
        super().__init__(master, fg_color="transparent", corner_radius=0)
        self.db = db
        self._build()

    def _build(self):
        name = self.db.get_user_name()
        hdr = ctk.CTkFrame(self, fg_color="transparent")
        hdr.pack(fill="x", pady=(0, 12))
        title_lbl = ctk.CTkLabel(hdr, text=f"👋  Merhaba, {name}!",
                                  font=ctk.CTkFont(size=18, weight="bold"),
                                  text_color=C["text"])
        title_lbl.pack(side="left")
        date_lbl = ctk.CTkLabel(hdr, text=date.today().strftime("%d %B %Y"),
                                 text_color=C["subtext"],
                                 font=ctk.CTkFont(size=11))
        date_lbl.pack(side="right")

        # Tekrar bildirimleri
        reviews = self.db.get_todays_reviews()
        if reviews:
            rev_card = Card(self, title=f"🔁  Bugün Tekrar Et  ({len(reviews)} konu)")
            rev_card.pack(fill="x", pady=(0, 10))
            inner = ctk.CTkScrollableFrame(rev_card, height=90,
                                            fg_color="transparent")
            inner.pack(fill="x", padx=10, pady=(0, 8))
            for r in reviews[:8]:
                row = ctk.CTkFrame(inner, fg_color=C["surface2"], corner_radius=6)
                row.pack(fill="x", pady=2)
                r_lbl = ctk.CTkLabel(row,
                                      text=f"{r.get('subject_icon','📚')}  {r['title']}",
                                      font=ctk.CTkFont(size=11),
                                      text_color=C["text"])
                r_lbl.pack(side="left", padx=10, pady=4)
                done_btn = ctk.CTkButton(row, text="✓ Tamam", width=80, height=24,
                                          font=ctk.CTkFont(size=10),
                                          fg_color=C["green"], text_color="#1E1E2E",
                                          command=lambda tid=r["id"]: self._mark(tid))
                done_btn.pack(side="right", padx=8)

        # Stat rozetleri
        prog     = self.db.get_progress()
        eta      = self.db.calculate_eta()
        summary  = self.db.get_day_summary(date.today())
        badges_data = [
            ("Biten Konu",     str(prog["done"]),                    C["green"]),
            ("Toplam Konu",    str(prog["total"]),                   C["accent"]),
            ("İlerleme",       f"%{prog['pct']}",                    C["yellow"]),
            ("Bugün Soru",     str(summary["total_questions"]),      C["teal"]),
            ("Bugün Pomodoro", str(summary["pomodoros"]),            C["mauve"]),
            ("Tahmini Bitiş",  eta.strftime("%d/%m/%Y") if eta else "—",
                               C["subtext"]),
        ]
        badge_frame = ctk.CTkFrame(self, fg_color="transparent")
        badge_frame.pack(fill="x", pady=(0, 10))
        for i, (lbl, val, col) in enumerate(badges_data):
            b = StatBadge(badge_frame, lbl, val, col)
            b.grid(row=0, column=i, padx=4, sticky="nsew")
            badge_frame.columnconfigure(i, weight=1)

        # Genel ilerleme
        prog_card = Card(self, title="📈  Genel Müfredat İlerlemesi")
        prog_card.pack(fill="x", pady=(0, 10))
        pb = ctk.CTkProgressBar(prog_card, height=14, corner_radius=7,
                                 progress_color=C["accent"])
        pb.pack(fill="x", padx=14, pady=(4, 2))
        pb.set(prog["pct"] / 100)
        pb_lbl = ctk.CTkLabel(prog_card,
                               text=f"{prog['done']} / {prog['total']} konu tamamlandı",
                               text_color=C["subtext"],
                               font=ctk.CTkFont(size=10))
        pb_lbl.pack(anchor="e", padx=14, pady=(0, 8))

        # Ders bazlı
        subj_card = Card(self, title="🎯  Ders Bazlı İlerleme")
        subj_card.pack(fill="x", pady=(0, 10))
        for s in self.db.get_subjects():
            p = self.db.get_progress(s["id"])
            if p["total"] == 0:
                continue
            color = SUBJ_COLORS.get(s["name"], C["accent"])
            progress_row(subj_card, f"{s['icon']}  {s['name']}", p["pct"], color)
        ctk.CTkFrame(subj_card, height=8, fg_color="transparent").pack()

    def _mark(self, topic_id: int):
        self.db.mark_review_done(topic_id, "1day")
        for w in self.winfo_children():
            w.destroy()
        self._build()


# ═══════════════════════════════════════════════════════════
# PANEL: POMODORO
# ═══════════════════════════════════════════════════════════
class PomodoroPanel(ctk.CTkScrollableFrame):
    def __init__(self, master, db: DatabaseManager):
        super().__init__(master, fg_color="transparent", corner_radius=0)
        self.db = db
        self.app_timer = AppTimer.get(db)
        # Panel bu timer'ın UI callback'lerini sahiplenir
        self.app_timer.tick_cb = self._on_tick
        self.app_timer.end_cb  = self._on_end

        self._focus_score      = ctk.IntVar(value=3)
        self._sel_subject_id: Optional[int] = None
        self._sel_topic_id:   Optional[int] = None
        self._topic_map:      dict = {}

        self._build()

    def _build(self):
        title_lbl = ctk.CTkLabel(self, text="⏱  Pomodoro Sayacı",
                                  font=ctk.CTkFont(size=18, weight="bold"),
                                  text_color=C["text"])
        title_lbl.pack(anchor="w", pady=(0, 10))

        # ── Saat kartı ────────────────────────────────────────────────────
        clock = Card(self)
        clock.pack(pady=(0, 10))

        timer = self.app_timer.timer
        init_text = f"{timer.work_min:02d}:00"
        self._time_lbl = ctk.CTkLabel(clock, text=init_text,
                                       font=ctk.CTkFont(family="Courier New",
                                                        size=72, weight="bold"),
                                       text_color=C["accent"])
        self._time_lbl.pack(pady=(12, 4))

        self._state_lbl = ctk.CTkLabel(clock, text="HAZIR",
                                        font=ctk.CTkFont(size=13),
                                        text_color=C["subtext"])
        self._state_lbl.pack()

        self._pomo_lbl = ctk.CTkLabel(clock,
                                       text=f"🍅 {timer.pomodoro_count} / {timer.pomodoros_per_set}",
                                       font=ctk.CTkFont(size=11),
                                       text_color=C["yellow"])
        self._pomo_lbl.pack(pady=(4, 10))

        btn_row = ctk.CTkFrame(clock, fg_color="transparent")
        btn_row.pack(pady=(0, 14))

        start_btn = ctk.CTkButton(btn_row, text="▶ Başlat", width=110, height=38,
                                   font=ctk.CTkFont(size=13),
                                   fg_color=C["accent"], text_color="#1E1E2E",
                                   hover_color="#6fa3f7",
                                   command=self._start)
        start_btn.pack(side="left", padx=5)

        pause_btn = ctk.CTkButton(btn_row, text="⏸ Duraklat", width=110, height=38,
                                   font=ctk.CTkFont(size=13),
                                   command=self._pause_resume)
        pause_btn.pack(side="left", padx=5)

        stop_btn = ctk.CTkButton(btn_row, text="⏹ Durdur", width=110, height=38,
                                  font=ctk.CTkFont(size=13),
                                  fg_color=C["surface2"],
                                  command=self._stop)
        stop_btn.pack(side="left", padx=5)

        # ── Ayarlar ───────────────────────────────────────────────────────
        set_card = Card(self, title="⚙️  Pomodoro Ayarları")
        set_card.pack(fill="x", pady=(0, 10))

        sg = ctk.CTkFrame(set_card, fg_color="transparent")
        sg.pack(fill="x", padx=14, pady=(4, 6))

        params = [
            ("Çalışma (dk)", "_sw_work",  str(timer.work_min)),
            ("Kısa Mola",    "_sw_short", str(timer.short_break_min)),
            ("Uzun Mola",    "_sw_long",  str(timer.long_break_min)),
            ("Set Boyutu",   "_sw_set",   str(timer.pomodoros_per_set)),
        ]
        for col_i, (lbl, attr, default) in enumerate(params):
            lbl_w = ctk.CTkLabel(sg, text=lbl, text_color=C["subtext"],
                                  font=ctk.CTkFont(size=10))
            lbl_w.grid(row=0, column=col_i, padx=6, pady=(0, 2), sticky="w")
            e = ctk.CTkEntry(sg, width=70, height=28)
            e.insert(0, default)
            e.grid(row=1, column=col_i, padx=6)
            setattr(self, attr, e)

        apply_btn = ctk.CTkButton(set_card, text="Uygula", width=90, height=28,
                                   font=ctk.CTkFont(size=11),
                                   command=self._apply_settings)
        apply_btn.pack(anchor="e", padx=14, pady=(0, 6))

        # Ses
        sound_row = ctk.CTkFrame(set_card, fg_color="transparent")
        sound_row.pack(fill="x", padx=14, pady=(0, 10))
        s_lbl = ctk.CTkLabel(sound_row, text="Sesli Uyarı:",
                              text_color=C["text"], font=ctk.CTkFont(size=11))
        s_lbl.pack(side="left")
        self._sound_sw = ctk.CTkSwitch(sound_row, text="", width=46,
                                        onvalue=True, offvalue=False,
                                        command=self._toggle_sound)
        self._sound_sw.pack(side="left", padx=8)
        if self.app_timer.sound_enabled:
            self._sound_sw.select()
        wav_name = (os.path.basename(self.app_timer.wav_path)
                    if self.app_timer.wav_path else "Varsayılan bip")
        self._wav_lbl = ctk.CTkLabel(sound_row, text=wav_name,
                                      text_color=C["subtext"],
                                      font=ctk.CTkFont(size=10))
        self._wav_lbl.pack(side="left", padx=4)
        wav_btn = ctk.CTkButton(sound_row, text="📁 .wav seç", width=90, height=26,
                                 font=ctk.CTkFont(size=10),
                                 command=self._pick_wav)
        wav_btn.pack(side="right")

        # ── Ders & Konu ───────────────────────────────────────────────────
        sel_card = Card(self, title="📚  Çalışılan Ders & Konu")
        sel_card.pack(fill="x", pady=(0, 10))

        subjects = self.db.get_subjects()
        self._subj_map_p = {s["name"]: s["id"] for s in subjects}

        subj_row = ctk.CTkFrame(sel_card, fg_color="transparent")
        subj_row.pack(fill="x", padx=14, pady=(4, 4))
        ctk.CTkLabel(subj_row, text="Ders:", width=60, text_color=C["text"],
                      font=ctk.CTkFont(size=11)).pack(side="left")
        self._subj_cb_p = ctk.CTkComboBox(subj_row,
                                            values=[s["name"] for s in subjects],
                                            width=200, height=30,
                                            command=self._subj_changed_p)
        self._subj_cb_p.pack(side="left", padx=8)

        topic_row = ctk.CTkFrame(sel_card, fg_color="transparent")
        topic_row.pack(fill="x", padx=14, pady=(0, 10))
        ctk.CTkLabel(topic_row, text="Konu:", width=60, text_color=C["text"],
                      font=ctk.CTkFont(size=11)).pack(side="left")
        self._topic_cb_p = ctk.CTkComboBox(topic_row, values=[], width=320, height=30)
        self._topic_cb_p.pack(side="left", padx=8)

        if subjects:
            self._subj_cb_p.set(subjects[0]["name"])
            self._subj_changed_p(subjects[0]["name"])

        # ── Odak puanı ────────────────────────────────────────────────────
        focus_card = Card(self, title="⭐  Odak Kalitesi")
        focus_card.pack(fill="x", pady=(0, 10))
        stars_row = ctk.CTkFrame(focus_card, fg_color="transparent")
        stars_row.pack(pady=(4, 10))
        for v in range(1, 6):
            rb = ctk.CTkRadioButton(stars_row, text=str(v), value=v,
                                     variable=self._focus_score,
                                     font=ctk.CTkFont(size=12),
                                     text_color=C["text"])
            rb.pack(side="left", padx=10)

        # ── Haftalık rapor ────────────────────────────────────────────────
        stats = self.db.get_study_stats(7)
        if stats:
            rep_card = Card(self, title="📅  Bu Hafta Çalışma")
            rep_card.pack(fill="x")
            fig = build_weekly_study_chart(stats)
            embed_chart(rep_card, fig)

        # Timer aktif durumdaysa göstergesi güncelle
        if self.app_timer.timer.state != SessionState.IDLE:
            self._state_lbl.configure(text="ÇALIŞIYOR...")

    # ── Yardımcılar ────────────────────────────────────────────────────────
    def _subj_changed_p(self, name: str):
        sid = self._subj_map_p.get(name)
        if sid is None:
            return
        self._sel_subject_id = sid
        topics = self.db.get_topics_flat(sid)
        self._topic_map_p = {t["title"]: t["id"] for t in topics}
        vals = [t["title"] for t in topics]
        self._topic_cb_p.configure(values=vals)
        self._topic_cb_p.set(vals[0] if vals else "")
        self._sel_topic_id = topics[0]["id"] if topics else None

    def _apply_settings(self):
        try:
            w = validate_pos(self._sw_work.get(),  "Çalışma")
            s = validate_pos(self._sw_short.get(), "Kısa mola")
            l = validate_pos(self._sw_long.get(),  "Uzun mola")
            p = validate_pos(self._sw_set.get(),   "Set boyutu")
        except ValueError as e:
            self._state_lbl.configure(text=str(e), text_color=C["red"])
            return
        self.app_timer.timer.update_settings(w, s, l, p)
        self.db.set_setting("pomodoro_work_min",  str(w))
        self.db.set_setting("pomodoro_short_min", str(s))
        self.db.set_setting("pomodoro_long_min",  str(l))
        self.db.set_setting("pomodoros_per_set",  str(p))
        self._time_lbl.configure(text=f"{w:02d}:00")
        self._state_lbl.configure(text="Kaydedildi ✓", text_color=C["green"])
        self.after(2000, lambda: self._state_lbl.configure(
            text="HAZIR", text_color=C["subtext"]))

    def _toggle_sound(self):
        self.app_timer.sound_enabled = bool(self._sound_sw.get())
        self.db.set_setting("sound_enabled",
                            "1" if self.app_timer.sound_enabled else "0")

    def _pick_wav(self):
        try:
            from tkinter import filedialog
            path = filedialog.askopenfilename(
                title="WAV Dosyası Seç",
                filetypes=[("WAV", "*.wav"), ("Tümü", "*.*")]
            )
            if path:
                self.app_timer.wav_path = path
                self.db.set_setting("sound_wav_path", path)
                self._wav_lbl.configure(text=os.path.basename(path))
        except Exception:
            pass

    # ── Timer callbacks (arka plan thread → after) ─────────────────────────
    def _on_tick(self, remaining: int):
        self.after(0, self._update_clock, remaining)

    def _on_end(self, state: SessionState):
        self.after(0, self._end_ui, state)

    def _update_clock(self, remaining: int):
        try:
            m, s = divmod(remaining, 60)
            self._time_lbl.configure(text=f"{m:02d}:{s:02d}")
            t = self.app_timer.timer
            self._pomo_lbl.configure(
                text=f"🍅 {t.pomodoro_count} / {t.pomodoros_per_set}")
        except Exception:
            pass

    def _end_ui(self, state: SessionState):
        try:
            self._state_lbl.configure(text="✓ TAMAMLANDI", text_color=C["green"])
            self._time_lbl.configure(text_color=C["green"])
            w = self.app_timer.timer.work_min
            self.after(3000, lambda: self._time_lbl.configure(
                text=f"{w:02d}:00", text_color=C["accent"]))
            self.after(3000, lambda: self._state_lbl.configure(
                text="HAZIR", text_color=C["subtext"]))
        except Exception:
            pass

    # ── Kontroller ─────────────────────────────────────────────────────────
    def _start(self):
        topic_title = self._topic_cb_p.get()
        self._sel_topic_id = self._topic_map_p.get(topic_title)
        sid = self.db.start_pomodoro(
            topic_id=self._sel_topic_id,
            subject_id=self._sel_subject_id,
            duration_min=self.app_timer.timer.work_min,
        )
        self.app_timer.active_session_id = sid
        # focus score callback'i güncelle
        self.app_timer.end_cb = self._on_end_with_focus
        self.app_timer.timer.start_work()
        self._state_lbl.configure(text="ÇALIŞIYOR...", text_color=C["subtext"])
        self._time_lbl.configure(text_color=C["accent"])

    def _on_end_with_focus(self, state: SessionState):
        """Odak puanını da kayıt eder."""
        play_notification_sound(
            "end" if state == SessionState.WORK else "break",
            wav_path=self.app_timer.wav_path or None,
            enabled=self.app_timer.sound_enabled,
        )
        if state == SessionState.WORK and self.app_timer.active_session_id:
            self.db.finish_pomodoro(
                self.app_timer.active_session_id,
                self.app_timer.timer.elapsed_minutes,
                self._focus_score.get(),
                completed=True,
            )
            self.app_timer.active_session_id = None
        self.after(0, self._end_ui, state)

    def _pause_resume(self):
        t = self.app_timer.timer
        if t.state == SessionState.PAUSED:
            t.resume()
            self._state_lbl.configure(text="ÇALIŞIYOR...", text_color=C["subtext"])
        else:
            t.pause()
            self._state_lbl.configure(text="DURAKLADI ⏸", text_color=C["yellow"])

    def _stop(self):
        at = self.app_timer
        if at.active_session_id:
            self.db.finish_pomodoro(
                at.active_session_id,
                at.timer.elapsed_minutes,
                self._focus_score.get(),
                completed=False,
            )
            at.active_session_id = None
        at.timer.stop()
        self._state_lbl.configure(text="HAZIR", text_color=C["subtext"])
        w = at.timer.work_min
        self._time_lbl.configure(text=f"{w:02d}:00", text_color=C["accent"])


# ═══════════════════════════════════════════════════════════
# PANEL: MÜFREDAT TAKİBİ
# ═══════════════════════════════════════════════════════════
class CurriculumPanel(ctk.CTkFrame):
    def __init__(self, master, db: DatabaseManager):
        super().__init__(master, fg_color="transparent")
        self.db = db
        self._tab_btns: dict = {}
        self._active_sid: Optional[int] = None
        self._build()

    def _build(self):
        title = ctk.CTkLabel(self, text="📚  Müfredat Takibi",
                              font=ctk.CTkFont(size=18, weight="bold"),
                              text_color=C["text"])
        title.pack(anchor="w", pady=(0, 8))

        subjects = self.db.get_subjects()
        if not subjects:
            no_lbl = ctk.CTkLabel(self, text="Müfredat yok. Yönetim sekmesinden ekle.",
                                   text_color=C["subtext"])
            no_lbl.pack()
            return

        tab_row = ctk.CTkFrame(self, fg_color=C["surface"], corner_radius=8)
        tab_row.pack(fill="x", pady=(0, 8))
        for s in subjects:
            color = SUBJ_COLORS.get(s["name"], C["accent"])
            btn = ctk.CTkButton(tab_row,
                                 text=f"{s['icon']} {s['name']}",
                                 width=120, height=30, corner_radius=6,
                                 font=ctk.CTkFont(size=11),
                                 fg_color="transparent",
                                 hover_color=C["surface2"],
                                 text_color=color, border_width=1,
                                 border_color=color,
                                 command=lambda sid=s["id"]: self._load(sid))
            btn.pack(side="left", padx=4, pady=4)
            self._tab_btns[s["id"]] = btn

        self._content = ctk.CTkScrollableFrame(self, fg_color=C["surface"],
                                                corner_radius=10)
        self._content.pack(fill="both", expand=True)
        self._load(subjects[0]["id"])

    def _load(self, sid: int):
        for bid, btn in self._tab_btns.items():
            s = next((x for x in self.db.get_subjects() if x["id"] == bid), None)
            if s:
                color = SUBJ_COLORS.get(s["name"], C["accent"])
                if bid == sid:
                    btn.configure(fg_color=color, text_color="#1E1E2E")
                else:
                    btn.configure(fg_color="transparent", text_color=color)
        self._active_sid = sid
        for w in self._content.winfo_children():
            w.destroy()
        self._render(self._content, self.db.get_topics_tree(sid), 0)

    def _render(self, parent, nodes, level):
        for node in nodes:
            has_ch = bool(node.get("children"))
            row = ctk.CTkFrame(parent, fg_color="transparent")
            row.pack(fill="x", pady=1)
            var = ctk.BooleanVar(value=bool(node["is_completed"]))
            cb = ctk.CTkCheckBox(
                row,
                text=node["title"],
                variable=var,
                font=ctk.CTkFont(size=11, weight="bold" if has_ch else "normal"),
                text_color=C["subtext"] if node["is_completed"] else C["text"],
                checkbox_width=16, checkbox_height=16,
                command=lambda tid=node["id"], v=var: self._toggle(tid, v)
            )
            cb.pack(side="left", padx=(14 + level * 20, 4), pady=2)
            if node["is_completed"] and node.get("review_1day"):
                rev_lbl = ctk.CTkLabel(row, text="🔁",
                                        font=ctk.CTkFont(size=10),
                                        text_color=C["yellow"])
                rev_lbl.pack(side="right", padx=8)
            if node.get("children"):
                ch_frame = ctk.CTkFrame(parent, fg_color="transparent")
                ch_frame.pack(fill="x")
                self._render(ch_frame, node["children"], level + 1)

    def _toggle(self, tid: int, var: ctk.BooleanVar):
        self.db.mark_topic_complete(tid, var.get())


# ═══════════════════════════════════════════════════════════
# PANEL: MÜFREDAT YÖNETİMİ
# ═══════════════════════════════════════════════════════════
class CurriculumManagerPanel(ctk.CTkScrollableFrame):
    def __init__(self, master, db: DatabaseManager):
        super().__init__(master, fg_color="transparent", corner_radius=0)
        self.db = db
        self._sel_sid: Optional[int] = None
        self._build()

    def _build(self):
        title = ctk.CTkLabel(self, text="🛠  Müfredat Yönetimi",
                              font=ctk.CTkFont(size=18, weight="bold"),
                              text_color=C["text"])
        title.pack(anchor="w", pady=(0, 10))

        # Ders ekleme
        sc = Card(self, title="📚  Dersler")
        sc.pack(fill="x", pady=(0, 10))

        ar = ctk.CTkFrame(sc, fg_color="transparent")
        ar.pack(fill="x", padx=14, pady=(4, 6))
        ctk.CTkLabel(ar, text="Ders:", width=60, text_color=C["text"],
                      font=ctk.CTkFont(size=11)).pack(side="left")
        self._new_sname = ctk.CTkEntry(ar, width=180, height=28,
                                        placeholder_text="Ders adı...")
        self._new_sname.pack(side="left", padx=6)
        ctk.CTkLabel(ar, text="İkon:", text_color=C["subtext"],
                      font=ctk.CTkFont(size=11)).pack(side="left")
        self._new_sicon = ctk.CTkEntry(ar, width=46, height=28)
        self._new_sicon.insert(0, "📚")
        self._new_sicon.pack(side="left", padx=4)
        add_s_btn = ctk.CTkButton(ar, text="+ Ekle", width=76, height=28,
                                   font=ctk.CTkFont(size=11),
                                   fg_color=C["green"], text_color="#1E1E2E",
                                   command=self._add_subject)
        add_s_btn.pack(side="left", padx=6)

        self._slist = ctk.CTkFrame(sc, fg_color="transparent")
        self._slist.pack(fill="x", padx=14, pady=(0, 10))
        self._refresh_slist()

        # Konu ekleme
        tc = Card(self, title="📝  Konular")
        tc.pack(fill="x", pady=(0, 10))
        tr = ctk.CTkFrame(tc, fg_color="transparent")
        tr.pack(fill="x", padx=14, pady=(4, 6))
        ctk.CTkLabel(tr, text="Konu:", width=60, text_color=C["text"],
                      font=ctk.CTkFont(size=11)).pack(side="left")
        self._new_tname = ctk.CTkEntry(tr, width=260, height=28,
                                        placeholder_text="Konu adı...")
        self._new_tname.pack(side="left", padx=6)
        add_t_btn = ctk.CTkButton(tr, text="+ Ekle", width=76, height=28,
                                   font=ctk.CTkFont(size=11),
                                   fg_color=C["green"], text_color="#1E1E2E",
                                   command=self._add_topic)
        add_t_btn.pack(side="left", padx=4)

        self._tlist = ctk.CTkScrollableFrame(tc, height=220, fg_color=C["surface2"],
                                              corner_radius=8)
        self._tlist.pack(fill="x", padx=14, pady=(0, 10))

        self._msg = ctk.CTkLabel(self, text="", font=ctk.CTkFont(size=11))
        self._msg.pack(pady=4)

        if self.db.get_subjects():
            self._sel_sid = self.db.get_subjects()[0]["id"]
            self._refresh_tlist()

    def _refresh_slist(self):
        for w in self._slist.winfo_children():
            w.destroy()
        for s in self.db.get_subjects():
            row = ctk.CTkFrame(self._slist, fg_color=C["surface2"], corner_radius=6)
            row.pack(fill="x", pady=2)
            color = SUBJ_COLORS.get(s["name"], C["accent"])
            name_lbl = ctk.CTkLabel(row, text=f"{s['icon']} {s['name']}",
                                     text_color=color,
                                     font=ctk.CTkFont(size=12),
                                     width=200, anchor="w")
            name_lbl.pack(side="left", padx=10, pady=4)
            edit_btn = ctk.CTkButton(row, text="Konuları Düzenle", width=140, height=26,
                                      font=ctk.CTkFont(size=10),
                                      command=lambda sid=s["id"]: self._pick_subject(sid))
            edit_btn.pack(side="left", padx=4)
            del_btn = ctk.CTkButton(row, text="🗑", width=32, height=26,
                                     fg_color=C["red"], text_color="#1E1E2E",
                                     font=ctk.CTkFont(size=11),
                                     command=lambda sid=s["id"]: self._del_subject(sid))
            del_btn.pack(side="right", padx=8)

    def _add_subject(self):
        name = self._new_sname.get().strip()
        icon = self._new_sicon.get().strip() or "📚"
        if not name:
            self._show("Ders adı boş olamaz.", C["red"])
            return
        try:
            self.db.add_subject(name, icon)
            self._new_sname.delete(0, "end")
            self._refresh_slist()
            self._show(f"'{name}' eklendi.", C["green"])
        except Exception as e:
            self._show(str(e), C["red"])

    def _del_subject(self, sid: int):
        self.db.delete_subject(sid)
        self._refresh_slist()
        self._show("Ders silindi.", C["yellow"])

    def _pick_subject(self, sid: int):
        self._sel_sid = sid
        self._refresh_tlist()

    def _refresh_tlist(self):
        for w in self._tlist.winfo_children():
            w.destroy()
        if not self._sel_sid:
            return
        for t in self.db.get_topics_all(self._sel_sid):
            indent = 20 if t["parent_id"] else 0
            row = ctk.CTkFrame(self._tlist, fg_color="transparent")
            row.pack(fill="x", pady=1)
            prefix = "  └─ " if t["parent_id"] else ""
            t_lbl = ctk.CTkLabel(row, text=f"{prefix}{t['title']}",
                                  text_color=C["subtext"] if t["parent_id"] else C["text"],
                                  font=ctk.CTkFont(size=10 if t["parent_id"] else 11),
                                  anchor="w")
            t_lbl.pack(side="left", padx=(14 + indent, 4))
            del_btn = ctk.CTkButton(row, text="🗑", width=28, height=22,
                                     fg_color=C["surface2"], text_color=C["red"],
                                     font=ctk.CTkFont(size=10),
                                     command=lambda tid=t["id"]: self._del_topic(tid))
            del_btn.pack(side="right", padx=6)

    def _add_topic(self):
        if not self._sel_sid:
            self._show("Önce ders seç.", C["red"])
            return
        title = self._new_tname.get().strip()
        if not title:
            self._show("Konu adı boş olamaz.", C["red"])
            return
        self.db.add_topic(self._sel_sid, title)
        self._new_tname.delete(0, "end")
        self._refresh_tlist()
        self._show(f"'{title}' eklendi.", C["green"])

    def _del_topic(self, tid: int):
        self.db.delete_topic(tid)
        self._refresh_tlist()
        self._show("Konu silindi.", C["yellow"])

    def _show(self, text: str, color: str):
        self._msg.configure(text=text, text_color=color)
        self.after(3000, lambda: self._msg.configure(text=""))


# ═══════════════════════════════════════════════════════════
# PANEL: ANALİTİK  (sticky konu seçimi)
# ═══════════════════════════════════════════════════════════
class AnalyticsPanel(ctk.CTkScrollableFrame):
    def __init__(self, master, db: DatabaseManager):
        super().__init__(master, fg_color="transparent", corner_radius=0)
        self.db = db
        self._topic_map: dict = {}
        self._sticky_subj: str = db.get_setting("last_subj", "")
        self._sticky_topic: str = db.get_setting("last_topic", "")
        self._build()

    def _build(self):
        title = ctk.CTkLabel(self, text="📊  Soru & Hata Analitği",
                              font=ctk.CTkFont(size=18, weight="bold"),
                              text_color=C["text"])
        title.pack(anchor="w", pady=(0, 10))

        form = Card(self, title="➕  Günlük Soru Girişi")
        form.pack(fill="x", pady=(0, 10))

        subjects = self.db.get_subjects()
        self._subj_map = {s["name"]: s["id"] for s in subjects}

        # Sticky badge
        if self._sticky_subj or self._sticky_topic:
            stick_row = ctk.CTkFrame(form, fg_color=C["surface2"], corner_radius=6)
            stick_row.pack(fill="x", padx=14, pady=(4, 2))
            stick_lbl = ctk.CTkLabel(stick_row,
                                      text=f"📌 Son: {self._sticky_subj} › {self._sticky_topic}",
                                      text_color=C["teal"],
                                      font=ctk.CTkFont(size=10))
            stick_lbl.pack(side="left", padx=10, pady=4)
            use_btn = ctk.CTkButton(stick_row, text="Bunu Kullan", width=90, height=22,
                                     font=ctk.CTkFont(size=10),
                                     fg_color=C["teal"], text_color="#1E1E2E",
                                     command=self._use_sticky)
            use_btn.pack(side="right", padx=8)

        # Ders
        r1 = ctk.CTkFrame(form, fg_color="transparent")
        r1.pack(fill="x", padx=14, pady=(6, 4))
        ctk.CTkLabel(r1, text="Ders:", width=70, text_color=C["text"],
                      font=ctk.CTkFont(size=11)).pack(side="left")
        self._subj_cb = ctk.CTkComboBox(r1, values=list(self._subj_map.keys()),
                                         width=180, height=30,
                                         command=self._subj_changed)
        self._subj_cb.pack(side="left", padx=6)

        # Konu (zorunlu)
        r2 = ctk.CTkFrame(form, fg_color="transparent")
        r2.pack(fill="x", padx=14, pady=(0, 4))
        ctk.CTkLabel(r2, text="Konu *:", width=70, text_color=C["text"],
                      font=ctk.CTkFont(size=11)).pack(side="left")
        self._topic_cb = ctk.CTkComboBox(r2, values=[], width=320, height=30)
        self._topic_cb.pack(side="left", padx=6)

        # Sayılar
        r3 = ctk.CTkFrame(form, fg_color="transparent")
        r3.pack(fill="x", padx=14, pady=(0, 4))
        for lbl, attr, ph in [
            ("Toplam:", "_tot_e", "40"),
            ("Doğru:",  "_cor_e", "28"),
        ]:
            ctk.CTkLabel(r3, text=lbl, text_color=C["text"],
                          font=ctk.CTkFont(size=11)).pack(side="left", padx=(0, 4))
            e = ctk.CTkEntry(r3, width=80, height=28, placeholder_text=ph)
            e.pack(side="left", padx=(0, 16))
            setattr(self, attr, e)

        # Hata
        r4 = ctk.CTkFrame(form, fg_color="transparent")
        r4.pack(fill="x", padx=14, pady=(0, 6))
        ctk.CTkLabel(r4, text="Hata:", text_color=C["subtext"],
                      font=ctk.CTkFont(size=10)).pack(side="left", padx=(0, 6))
        for lbl, attr in [("Bilgi", "_ek"), ("Dikkat", "_ea"), ("Süre", "_et")]:
            ctk.CTkLabel(r4, text=lbl + ":", text_color=C["subtext"],
                          font=ctk.CTkFont(size=9)).pack(side="left")
            e = ctk.CTkEntry(r4, width=44, height=26, placeholder_text="0")
            e.pack(side="left", padx=(2, 10))
            setattr(self, attr, e)

        self._form_msg = ctk.CTkLabel(form, text="", font=ctk.CTkFont(size=10))
        self._form_msg.pack(anchor="w", padx=14)

        save_btn = ctk.CTkButton(form, text="💾  Kaydet", height=32, width=120,
                                  font=ctk.CTkFont(size=12),
                                  fg_color=C["green"], text_color="#1E1E2E",
                                  hover_color="#88d49a",
                                  command=self._save)
        save_btn.pack(anchor="e", padx=14, pady=(4, 12))

        # İlk yükleme
        if subjects:
            init_s = self._sticky_subj if self._sticky_subj in self._subj_map else subjects[0]["name"]
            self._subj_cb.set(init_s)
            self._subj_changed(init_s)
            if self._sticky_topic and self._sticky_topic in self._topic_map:
                self._topic_cb.set(self._sticky_topic)

        # Grafik
        err = self.db.get_error_analysis()
        if err:
            gc = Card(self, title="📉  Derse Göre Hata Analizi")
            gc.pack(fill="both", expand=True)
            fig = build_error_chart(err)
            embed_chart(gc, fig)

    def _subj_changed(self, name: str):
        sid = self._subj_map.get(name)
        if sid is None:
            return
        topics = self.db.get_topics_flat(sid)
        self._topic_map = {t["title"]: t["id"] for t in topics}
        vals = [t["title"] for t in topics]
        self._topic_cb.configure(values=vals)
        self._topic_cb.set(vals[0] if vals else "(Konu yok)")

    def _use_sticky(self):
        if self._sticky_subj in self._subj_map:
            self._subj_cb.set(self._sticky_subj)
            self._subj_changed(self._sticky_subj)
        if self._sticky_topic in self._topic_map:
            self._topic_cb.set(self._sticky_topic)

    def _save(self):
        try:
            sname  = self._subj_cb.get()
            sid    = self._subj_map.get(sname)
            tname  = self._topic_cb.get()
            tid    = self._topic_map.get(tname)

            if not sid:
                raise ValueError("Ders seçilmedi.")
            if not tid:
                raise ValueError("Konu seçilmedi. Yönetim sekmesinden ekle.")

            tot = validate_pos(self._tot_e.get(),    "Toplam soru")
            cor = validate_nneg(self._cor_e.get(),   "Doğru")
            if cor > tot:
                raise ValueError("Doğru sayısı toplam sorudan fazla.")
            ek  = validate_nneg(self._ek.get() or "0", "Bilgi hatası")
            ea  = validate_nneg(self._ea.get() or "0", "Dikkat hatası")
            et  = validate_nneg(self._et.get() or "0", "Süre hatası")

            self.db.log_questions(sid, tid, tot, cor, ek, ea, et)

            # Sticky güncelle
            self.db.set_setting("last_subj",  sname)
            self.db.set_setting("last_topic", tname)

            for e in (self._tot_e, self._cor_e, self._ek, self._ea, self._et):
                e.delete(0, "end")
            self._form_msg.configure(text="✓ Kaydedildi!", text_color=C["green"])
            self.after(2000, lambda: self._form_msg.configure(text=""))

        except ValueError as e:
            self._form_msg.configure(text=str(e), text_color=C["red"])


# ═══════════════════════════════════════════════════════════
# PANEL: TAKVİM
# ═══════════════════════════════════════════════════════════
class CalendarPanel(ctk.CTkScrollableFrame):
    def __init__(self, master, db: DatabaseManager):
        super().__init__(master, fg_color="transparent", corner_radius=0)
        self.db = db
        self._year  = date.today().year
        self._month = date.today().month
        self._build()

    def _build(self):
        title = ctk.CTkLabel(self, text="📅  Çalışma Takvimi",
                              font=ctk.CTkFont(size=18, weight="bold"),
                              text_color=C["text"])
        title.pack(anchor="w", pady=(0, 10))

        nav = ctk.CTkFrame(self, fg_color=C["surface"], corner_radius=8)
        nav.pack(fill="x", pady=(0, 8))
        prev_btn = ctk.CTkButton(nav, text="◀", width=36, height=30,
                                  fg_color="transparent",
                                  command=self._prev)
        prev_btn.pack(side="left", padx=6)
        self._nav_lbl = ctk.CTkLabel(nav, text="",
                                      font=ctk.CTkFont(size=13, weight="bold"),
                                      text_color=C["text"])
        self._nav_lbl.pack(side="left", expand=True)
        next_btn = ctk.CTkButton(nav, text="▶", width=36, height=30,
                                  fg_color="transparent",
                                  command=self._next)
        next_btn.pack(side="right", padx=6)

        self._grid_frame = ctk.CTkFrame(self, fg_color=C["surface"],
                                         corner_radius=8)
        self._grid_frame.pack(fill="x", pady=(0, 10))

        self._detail = Card(self, title="")
        self._detail.pack(fill="x")

        self._render_grid()

    def _render_grid(self):
        for w in self._grid_frame.winfo_children():
            w.destroy()

        MONTHS = ["","Ocak","Şubat","Mart","Nisan","Mayıs","Haziran",
                   "Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"]
        DAYS   = ["Pzt","Sal","Çar","Per","Cum","Cmt","Paz"]
        self._nav_lbl.configure(text=f"{MONTHS[self._month]}  {self._year}")

        for col, d in enumerate(DAYS):
            d_lbl = ctk.CTkLabel(self._grid_frame, text=d,
                                  font=ctk.CTkFont(size=10, weight="bold"),
                                  text_color=C["subtext"], width=48)
            d_lbl.grid(row=0, column=col, padx=2, pady=(8, 4))

        hm = self.db.get_heatmap_data(self._year)
        heat_c = [C["surface2"], "#304E7A", "#3D6699", "#4A7EB8", "#89B4FA"]
        today  = date.today()

        for wi, week in enumerate(cal_module.monthcalendar(self._year, self._month)):
            for di, day in enumerate(week):
                if day == 0:
                    sp = ctk.CTkFrame(self._grid_frame, width=48, height=40,
                                       fg_color="transparent")
                    sp.grid(row=wi + 1, column=di, padx=2, pady=2)
                    continue
                d_obj  = date(self._year, self._month, day)
                d_str  = d_obj.isoformat()
                intens = hm.get(d_str, 0)
                bg     = heat_c[min(intens, 4)]
                is_td  = (d_obj == today)
                btn = ctk.CTkButton(
                    self._grid_frame,
                    text=str(day), width=48, height=40,
                    corner_radius=6,
                    font=ctk.CTkFont(size=11, weight="bold" if is_td else "normal"),
                    fg_color=bg, hover_color=C["accent"],
                    text_color="#1E1E2E" if intens >= 2 else C["text"],
                    border_width=2 if is_td else 0,
                    border_color=C["accent"],
                    command=lambda dd=d_obj: self._show_day(dd)
                )
                btn.grid(row=wi + 1, column=di, padx=2, pady=2)

        sp2 = ctk.CTkFrame(self._grid_frame, height=8, fg_color="transparent")
        sp2.grid(row=10, column=0, columnspan=7)

    def _show_day(self, d: date):
        for w in self._detail.winfo_children():
            w.destroy()
        s = self.db.get_day_summary(d)

        MONTHS = ["","Ocak","Şubat","Mart","Nisan","Mayıs","Haziran",
                   "Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"]
        h_title = ctk.CTkLabel(self._detail,
                                text=f"📋  {d.day} {MONTHS[d.month]} {d.year}",
                                font=ctk.CTkFont(size=13, weight="bold"),
                                text_color=C["text"])
        h_title.pack(anchor="w", padx=14, pady=(10, 6))

        items = [
            ("📝 Toplam Soru",   str(s["total_questions"])),
            ("✅ Doğru",         str(s["correct_questions"])),
            ("⏱ Çalışma",
             f"{s['study_minutes']//60}s {s['study_minutes']%60}dk"),
            ("🍅 Pomodoro",      str(s["pomodoros"])),
            ("📚 Biten Konu",    str(s["topics_completed"])),
        ]
        for lbl, val in items:
            row = ctk.CTkFrame(self._detail, fg_color=C["surface2"],
                                corner_radius=6)
            row.pack(fill="x", padx=14, pady=2)
            ctk.CTkLabel(row, text=lbl, text_color=C["subtext"],
                          font=ctk.CTkFont(size=11)).pack(side="left", padx=10, pady=5)
            ctk.CTkLabel(row, text=val,
                          font=ctk.CTkFont(size=12, weight="bold"),
                          text_color=C["text"]).pack(side="right", padx=10)

        # Konu detayı
        if s["topic_detail"]:
            td_lbl = ctk.CTkLabel(self._detail, text="Konu Bazlı:",
                                   text_color=C["subtext"],
                                   font=ctk.CTkFont(size=10, weight="bold"))
            td_lbl.pack(anchor="w", padx=14, pady=(8, 2))
            for td in s["topic_detail"][:6]:
                acc = round(td["correct"] / td["total"] * 100) if td["total"] else 0
                t_row = ctk.CTkFrame(self._detail, fg_color=C["surface2"],
                                      corner_radius=5)
                t_row.pack(fill="x", padx=14, pady=1)
                t_lbl = ctk.CTkLabel(t_row,
                                      text=f"{td['subject']} › {td['topic']}",
                                      text_color=C["text"],
                                      font=ctk.CTkFont(size=10))
                t_lbl.pack(side="left", padx=8, pady=3)
                acc_lbl = ctk.CTkLabel(t_row,
                                        text=f"{td['total']} soru  %{acc} doğru",
                                        text_color=C["green"] if acc >= 70
                                        else (C["yellow"] if acc >= 50 else C["red"]),
                                        font=ctk.CTkFont(size=10))
                acc_lbl.pack(side="right", padx=8)

        ctk.CTkFrame(self._detail, height=8, fg_color="transparent").pack()

    def _prev(self):
        if self._month == 1:
            self._month, self._year = 12, self._year - 1
        else:
            self._month -= 1
        self._render_grid()

    def _next(self):
        if self._month == 12:
            self._month, self._year = 1, self._year + 1
        else:
            self._month += 1
        self._render_grid()


# ═══════════════════════════════════════════════════════════
# PANEL: HEATMAP & PLANLAYICI
# ═══════════════════════════════════════════════════════════
class HeatmapPlannerPanel(ctk.CTkScrollableFrame):
    def __init__(self, master, db: DatabaseManager):
        super().__init__(master, fg_color="transparent", corner_radius=0)
        self.db = db
        self._build()

    def _build(self):
        title = ctk.CTkLabel(self, text="🗓  Aktivite & Planlayıcı",
                              font=ctk.CTkFont(size=18, weight="bold"),
                              text_color=C["text"])
        title.pack(anchor="w", pady=(0, 10))

        hm_card = Card(self, title=f"🔥  {date.today().year} Aktivite Haritası")
        hm_card.pack(fill="x", pady=(0, 12))
        fig = build_heatmap(self.db.get_heatmap_data(date.today().year),
                             date.today().year)
        embed_chart(hm_card, fig)

        plan_card = Card(self, title="📋  Yarın İçin Plan")
        plan_card.pack(fill="x")
        tomorrow = date.today() + timedelta(days=1)
        existing = self.db.get_plan(tomorrow)

        r1 = ctk.CTkFrame(plan_card, fg_color="transparent")
        r1.pack(fill="x", padx=14, pady=(6, 4))
        for lbl, attr, ph, ex_k in [
            ("Hedef Soru:", "_pq", "100", "target_questions"),
            ("Hedef (dk):", "_pm", "300", "target_study_min"),
        ]:
            ctk.CTkLabel(r1, text=lbl, text_color=C["text"],
                          font=ctk.CTkFont(size=11)).pack(side="left", padx=(0, 4))
            e = ctk.CTkEntry(r1, width=80, height=28, placeholder_text=ph)
            if existing and existing.get(ex_k):
                e.insert(0, str(existing[ex_k]))
            e.pack(side="left", padx=(0, 16))
            setattr(self, attr, e)

        ctk.CTkLabel(plan_card, text="Notlar:", text_color=C["text"],
                      font=ctk.CTkFont(size=11)).pack(anchor="w", padx=14)
        self._notes = ctk.CTkTextbox(plan_card, width=400, height=60,
                                      fg_color=C["surface2"])
        if existing and existing.get("notes"):
            self._notes.insert("0.0", existing["notes"])
        self._notes.pack(padx=14, pady=(4, 0))

        self._pmsg = ctk.CTkLabel(plan_card, text="", font=ctk.CTkFont(size=10))
        self._pmsg.pack(anchor="w", padx=14)

        save_btn = ctk.CTkButton(plan_card, text="💾  Planı Kaydet",
                                  height=32, width=140, font=ctk.CTkFont(size=12),
                                  fg_color=C["accent"], text_color="#1E1E2E",
                                  command=self._save)
        save_btn.pack(anchor="e", padx=14, pady=(6, 12))

        today_plan = self.db.get_plan(date.today())
        if today_plan:
            comp = self.db.get_plan_completion(date.today())
            cc = Card(plan_card, title="✅  Bugünkü Plan")
            cc.pack(fill="x", padx=14, pady=(0, 10))
            progress_row(cc, "📝 Soru Hedefi",   comp.get("question_pct", 0), C["green"])
            progress_row(cc, "⏱ Çalışma Hedefi", comp.get("study_pct",    0), C["accent"])
            ctk.CTkFrame(cc, height=6, fg_color="transparent").pack()

    def _save(self):
        tomorrow = date.today() + timedelta(days=1)
        try:
            q = validate_nneg(self._pq.get() or "0", "Soru hedefi")
            m = validate_nneg(self._pm.get() or "0", "Süre hedefi")
            notes = self._notes.get("0.0", "end").strip()
            self.db.save_plan(tomorrow, [], q, m, notes)
            self._pmsg.configure(text="✓ Kaydedildi!", text_color=C["green"])
            self.after(2000, lambda: self._pmsg.configure(text=""))
        except ValueError as e:
            self._pmsg.configure(text=str(e), text_color=C["red"])


# ═══════════════════════════════════════════════════════════
# PANEL: DETAYLI RAPOR
# ═══════════════════════════════════════════════════════════

class RaporPanel(ctk.CTkFrame):
    """
    Soru performansını günlük / haftalık / aylık; ders ve konu bazında
    hem grafik hem yazı formatında gösteren rapor merkezi.
    """

    PERIODS = [("Günlük", "daily"), ("Haftalık", "weekly"), ("Aylık", "monthly")]
    RANGES  = [("Son 7 Gün", 7), ("Son 14 Gün", 14), ("Son 30 Gün", 30),
               ("Son 90 Gün", 90), ("Tüm Zamanlar", 3650)]
    VIEWS   = ["Özet", "Zaman Grafiği", "Ders Analizi", "Konu Detayı",
               "Doğruluk Trendi", "Hata Analizi", "Metin Raporu"]

    def __init__(self, master, db: DatabaseManager):
        super().__init__(master, fg_color="transparent")
        self.db = db
        self._period = ctk.StringVar(value="daily")
        self._range  = ctk.IntVar(value=30)
        self._view   = ctk.StringVar(value="Özet")
        # Konu filtresinde seçili ders
        self._filter_subj_id: Optional[int] = None
        self._build()

    def _build(self):
        # ── Başlık satırı ────────────────────────────────────────────────
        hdr = ctk.CTkFrame(self, fg_color="transparent")
        hdr.pack(fill="x", pady=(0, 8))

        title_lbl = ctk.CTkLabel(
            hdr, text="📈  Soru Performans Raporu",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=C["text"]
        )
        title_lbl.pack(side="left")

        export_btn = ctk.CTkButton(
            hdr, text="📋 Metin Kopyala", width=130, height=30,
            font=ctk.CTkFont(size=11),
            fg_color=C["surface2"],
            command=self._copy_text_report
        )
        export_btn.pack(side="right")

        # ── Kontrol çubuğu ────────────────────────────────────────────────
        ctrl = ctk.CTkFrame(self, fg_color=C["surface"], corner_radius=10)
        ctrl.pack(fill="x", pady=(0, 10))

        # Görünüm seçimi
        ctk.CTkLabel(ctrl, text="Görünüm:", text_color=C["subtext"],
                     font=ctk.CTkFont(size=10)).grid(row=0, column=0, padx=(12,4), pady=8)
        view_cb = ctk.CTkComboBox(
            ctrl, values=self.VIEWS,
            variable=self._view, width=150, height=28,
            command=lambda _: self._refresh()
        )
        view_cb.grid(row=0, column=1, padx=4)

        # Dönem
        ctk.CTkLabel(ctrl, text="Dönem:", text_color=C["subtext"],
                     font=ctk.CTkFont(size=10)).grid(row=0, column=2, padx=(16,4))
        for lbl, val in self.PERIODS:
            rb = ctk.CTkRadioButton(
                ctrl, text=lbl, value=val, variable=self._period,
                font=ctk.CTkFont(size=11), text_color=C["text"],
                command=self._refresh
            )
            rb.grid(row=0, column=3 + self.PERIODS.index((lbl,val)), padx=4)

        # Aralık
        ctk.CTkLabel(ctrl, text="Aralık:", text_color=C["subtext"],
                     font=ctk.CTkFont(size=10)).grid(row=0, column=7, padx=(16,4))
        range_cb = ctk.CTkComboBox(
            ctrl, values=[r[0] for r in self.RANGES],
            width=120, height=28,
            command=self._range_changed
        )
        range_cb.set("Son 30 Gün")
        range_cb.grid(row=0, column=8, padx=(4,12))

        # ── İçerik alanı (scrollable) ─────────────────────────────────────
        self._scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent", corner_radius=0
        )
        self._scroll.pack(fill="both", expand=True)

        self._refresh()

    # ── Kontrol yardımcıları ──────────────────────────────────────────────
    def _range_changed(self, label: str):
        for lbl, days in self.RANGES:
            if lbl == label:
                self._range.set(days)
                break
        self._refresh()

    def _refresh(self):
        for w in self._scroll.winfo_children():
            w.destroy()
        view = self._view.get()
        dispatch = {
            "Özet":             self._render_summary,
            "Zaman Grafiği":    self._render_time_chart,
            "Ders Analizi":     self._render_subject,
            "Konu Detayı":      self._render_topic,
            "Doğruluk Trendi":  self._render_trend,
            "Hata Analizi":     self._render_errors,
            "Metin Raporu":     self._render_text,
        }
        fn = dispatch.get(view, self._render_summary)
        try:
            fn()
        except Exception as e:
            ctk.CTkLabel(self._scroll, text=f"Görünüm hatası: {e}",
                         text_color=C["red"]).pack(pady=20)

    # ── GÖRÜNÜM 1: ÖZET ───────────────────────────────────────────────────
    def _render_summary(self):
        days = self._range.get()
        totals_data = self.db.get_report_summary_totals()
        subj_data   = self.db.get_report_by_subject(since_days=days)

        # Genel istatistik kartları
        stat_card = Card(self._scroll, title="🏆  Genel İstatistikler")
        stat_card.pack(fill="x", pady=(0, 10))

        grid = ctk.CTkFrame(stat_card, fg_color="transparent")
        grid.pack(fill="x", padx=14, pady=(4, 12))

        stats = [
            ("📝 Toplam Soru",     str(totals_data.get("total_q", 0)),      C["accent"]),
            ("✅ Toplam Doğru",    str(totals_data.get("correct_q", 0)),    C["green"]),
            ("🎯 Genel Doğruluk",  f"%{totals_data.get('accuracy') or 0}",  C["teal"]),
            ("📅 Aktif Gün",       str(totals_data.get("active_days", 0)),  C["yellow"]),
            ("🔥 Güncel Seri",     f"{totals_data.get('current_streak',0)} gün", C["mauve"]),
            ("🏅 En Uzun Seri",    f"{totals_data.get('longest_streak',0)} gün", C["accent"]),
        ]
        for i, (lbl, val, col) in enumerate(stats):
            b = StatBadge(grid, lbl, val, col)
            b.grid(row=0, column=i, padx=4, sticky="nsew")
            grid.columnconfigure(i, weight=1)

        # Ders bazlı mini-tablo
        if subj_data:
            tbl_card = Card(self._scroll, title=f"📊  Son {days} Günde Ders Performansı")
            tbl_card.pack(fill="x", pady=(0, 10))
            self._draw_subject_table(tbl_card, subj_data)

            # Radar grafik
            chart_card = Card(self._scroll, title="🕸️  Ders Radar")
            chart_card.pack(fill="x", pady=(0, 10))
            fig = build_subject_radar(subj_data)
            self._embed(chart_card, fig)

    # ── GÖRÜNÜM 2: ZAMAN GRAFİĞİ ──────────────────────────────────────────
    def _render_time_chart(self):
        period = self._period.get()
        days   = self._range.get()
        # monthly için limit ayarla
        limit = max(12, days // 7) if period == "weekly" else (
                max(12, days // 30) if period == "monthly" else days)

        data = self.db.get_report_by_period(period=period, limit=limit)
        if not data:
            self._no_data()
            return

        chart_card = Card(self._scroll,
                          title=f"📊  {self._period_label()} Soru & Doğruluk")
        chart_card.pack(fill="x", pady=(0, 10))
        fig = build_period_bar(data, period)
        self._embed(chart_card, fig)

        # Tablo
        tbl_card = Card(self._scroll, title="📋  Tablo")
        tbl_card.pack(fill="x", pady=(0, 10))
        self._draw_period_table(tbl_card, data)

    # ── GÖRÜNÜM 3: DERS ANALİZİ ───────────────────────────────────────────
    def _render_subject(self):
        days = self._range.get()
        data = self.db.get_report_by_subject(since_days=days)
        if not data:
            self._no_data()
            return

        chart_card = Card(self._scroll,
                          title=f"📊  Ders Bazlı Performans  (Son {days} Gün)")
        chart_card.pack(fill="x", pady=(0, 10))
        fig = build_subject_bar(data)
        self._embed(chart_card, fig)

        tbl_card = Card(self._scroll, title="📋  Ders Tablosu")
        tbl_card.pack(fill="x", pady=(0, 10))
        self._draw_subject_table(tbl_card, data)

    # ── GÖRÜNÜM 4: KONU DETAYI ────────────────────────────────────────────
    def _render_topic(self):
        days = self._range.get()
        subjects = self.db.get_subjects()

        # Ders filtresi
        filter_row = ctk.CTkFrame(self._scroll, fg_color=C["surface"],
                                   corner_radius=8)
        filter_row.pack(fill="x", pady=(0, 8))
        ctk.CTkLabel(filter_row, text="Ders filtresi:",
                     text_color=C["subtext"],
                     font=ctk.CTkFont(size=11)).pack(side="left", padx=10)
        subj_names = ["Tümü"] + [s["name"] for s in subjects]
        subj_map   = {"Tümü": None, **{s["name"]: s["id"] for s in subjects}}
        flt_cb = ctk.CTkComboBox(
            filter_row, values=subj_names, width=160, height=28,
            command=lambda name: self._topic_filter_changed(name, subj_map, days)
        )
        current_name = next((s["name"] for s in subjects
                              if s["id"] == self._filter_subj_id), "Tümü")
        flt_cb.set(current_name)
        flt_cb.pack(side="left", padx=6, pady=6)

        data = self.db.get_report_by_topic(
            subject_id=self._filter_subj_id, since_days=days
        )
        if not data:
            self._no_data()
            return

        chart_card = Card(self._scroll, title="📊  Konu Bazlı Performans")
        chart_card.pack(fill="x", pady=(0, 10))
        fig = build_topic_treemap(data)
        self._embed(chart_card, fig)

        tbl_card = Card(self._scroll, title="📋  Konu Tablosu")
        tbl_card.pack(fill="x", pady=(0, 10))
        self._draw_topic_table(tbl_card, data)

    def _topic_filter_changed(self, name: str, subj_map: dict, days: int):
        self._filter_subj_id = subj_map.get(name)
        self._refresh()

    # ── GÖRÜNÜM 5: DOĞRULUK TRENDİ ───────────────────────────────────────
    def _render_trend(self):
        days = self._range.get()
        data = self.db.get_report_trend(since_days=min(days, 60))
        if not data:
            self._no_data()
            return

        chart_card = Card(self._scroll,
                          title=f"📉  Doğruluk Trendi  (Son {min(days,60)} Gün)")
        chart_card.pack(fill="x", pady=(0, 10))
        fig = build_accuracy_trend(data)
        self._embed(chart_card, fig)

        # Mini istatistikler
        accuracies = [float(d["accuracy"] or 0) for d in data if d["accuracy"]]
        if accuracies:
            stat_card = Card(self._scroll, title="📐  Trend İstatistikleri")
            stat_card.pack(fill="x", pady=(0, 10))
            mini_grid = ctk.CTkFrame(stat_card, fg_color="transparent")
            mini_grid.pack(fill="x", padx=14, pady=(4, 12))
            mini_stats = [
                ("Ortalama",   f"%{sum(accuracies)/len(accuracies):.1f}",  C["accent"]),
                ("En Yüksek",  f"%{max(accuracies):.1f}",                 C["green"]),
                ("En Düşük",   f"%{min(accuracies):.1f}",                 C["red"]),
                ("Son Gün",    f"%{accuracies[-1]:.1f}",                  C["teal"]),
            ]
            for i, (lbl, val, col) in enumerate(mini_stats):
                b = StatBadge(mini_grid, lbl, val, col)
                b.grid(row=0, column=i, padx=4, sticky="nsew")
                mini_grid.columnconfigure(i, weight=1)

    # ── GÖRÜNÜM 6: HATA ANALİZİ ───────────────────────────────────────────
    def _render_errors(self):
        days = self._range.get()
        data = self.db.get_report_by_subject(since_days=days)
        if not data:
            self._no_data()
            return

        # Donut pasta
        pie_card = Card(self._scroll, title="🍩  Hata Tipi Dağılımı")
        pie_card.pack(fill="x", pady=(0, 10))
        fig_pie = build_error_breakdown_pie(data)
        self._embed(pie_card, fig_pie)

        # Grouped bar (mevcut)
        bar_card = Card(self._scroll, title="📊  Derse Göre Hata Detayı")
        bar_card.pack(fill="x", pady=(0, 10))
        err_data = self.db.get_error_analysis()
        if err_data:
            fig_bar = build_error_chart(err_data)
            self._embed(bar_card, fig_bar)

        # Tablo
        tbl_card = Card(self._scroll, title="📋  Hata Tablosu")
        tbl_card.pack(fill="x", pady=(0, 10))
        cols = ["Ders", "Bilgi", "Dikkat", "Süre", "Toplam Hata"]
        widths = [140, 80, 80, 80, 110]
        self._table_header(tbl_card, cols, widths)
        for d in data:
            ek = d.get("err_k", 0) or 0
            ea = d.get("err_a", 0) or 0
            et = d.get("err_t", 0) or 0
            vals = [
                f"{d.get('icon','')} {d['subject']}",
                str(ek), str(ea), str(et), str(ek + ea + et)
            ]
            colors = [C["text"], C["red"], C["yellow"], C["teal"],
                      C["red"] if (ek+ea+et) > 20 else C["text"]]
            self._table_row(tbl_card, vals, widths, colors)

    # ── GÖRÜNÜM 7: METİN RAPORU ───────────────────────────────────────────
    def _render_text(self):
        days  = self._range.get()
        period = self._period.get()
        report_text = self._generate_text_report(days, period)

        text_card = Card(self._scroll, title="📄  Metin Raporu")
        text_card.pack(fill="both", expand=True, pady=(0, 10))

        tb = ctk.CTkTextbox(
            text_card,
            font=ctk.CTkFont(family="Courier New", size=11),
            fg_color=C["surface2"],
            text_color=C["text"],
            wrap="none",
            height=520
        )
        tb.pack(fill="both", expand=True, padx=14, pady=(4, 10))
        tb.insert("0.0", report_text)
        tb.configure(state="disabled")

        copy_btn = ctk.CTkButton(
            text_card, text="📋 Panoya Kopyala", width=160, height=30,
            font=ctk.CTkFont(size=11),
            fg_color=C["accent"], text_color="#1E1E2E",
            command=lambda: self._copy_to_clipboard(report_text)
        )
        copy_btn.pack(anchor="e", padx=14, pady=(0, 10))

    # ── TABLO YARDIMCILARI ────────────────────────────────────────────────
    def _table_header(self, parent, cols, widths):
        row = ctk.CTkFrame(parent, fg_color=C["surface2"], corner_radius=6)
        row.pack(fill="x", padx=14, pady=(6, 2))
        for col, w in zip(cols, widths):
            ctk.CTkLabel(
                row, text=col, width=w, anchor="w",
                font=ctk.CTkFont(size=10, weight="bold"),
                text_color=C["accent"]
            ).pack(side="left", padx=6, pady=4)

    def _table_row(self, parent, vals, widths, colors=None):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=1)
        for i, (val, w) in enumerate(zip(vals, widths)):
            col = (colors[i] if colors and i < len(colors) else C["text"])
            ctk.CTkLabel(
                row, text=str(val), width=w, anchor="w",
                font=ctk.CTkFont(size=10), text_color=col
            ).pack(side="left", padx=6, pady=2)

    def _draw_period_table(self, parent, data):
        # En yeni → en eski sıra
        data_s = sorted(data, key=lambda x: x["period_label"], reverse=True)
        cols   = ["Dönem", "Toplam", "Doğru", "Yanlış", "Doğruluk"]
        widths = [140, 80, 80, 80, 90]
        self._table_header(parent, cols, widths)
        for d in data_s:
            acc = d["accuracy"] or 0
            color = C["green"] if acc >= 70 else (C["yellow"] if acc >= 50 else C["red"])
            self._table_row(
                parent,
                [d["period_label"], d["total"] or 0,
                 d["correct"] or 0, d["wrong"] or 0, f"%{acc}"],
                widths,
                [C["text"], C["text"], C["green"], C["red"], color]
            )
        ctk.CTkFrame(parent, height=8, fg_color="transparent").pack()

    def _draw_subject_table(self, parent, data):
        cols   = ["Ders", "Toplam", "Doğru", "Yanlış", "Doğruluk"]
        widths = [160, 80, 80, 80, 90]
        self._table_header(parent, cols, widths)
        for d in data:
            acc = d["accuracy"] or 0
            color = C["green"] if acc >= 70 else (C["yellow"] if acc >= 50 else C["red"])
            self._table_row(
                parent,
                [f"{d.get('icon','')} {d['subject']}", d["total"] or 0,
                 d["correct"] or 0, d["wrong"] or 0, f"%{acc}"],
                widths,
                [C["text"], C["text"], C["green"], C["red"], color]
            )
        ctk.CTkFrame(parent, height=8, fg_color="transparent").pack()

    def _draw_topic_table(self, parent, data):
        cols   = ["Konu", "Ders", "Toplam", "Doğru", "Doğruluk"]
        widths = [200, 120, 80, 80, 90]
        self._table_header(parent, cols, widths)
        for d in data:
            acc = d["accuracy"] or 0
            color = C["green"] if acc >= 70 else (C["yellow"] if acc >= 50 else C["red"])
            self._table_row(
                parent,
                [d["topic"][:28], d["subject"], d["total"] or 0,
                 d["correct"] or 0, f"%{acc}"],
                widths,
                [C["text"], C["subtext"], C["text"], C["green"], color]
            )
        ctk.CTkFrame(parent, height=8, fg_color="transparent").pack()

    # ── METİN RAPORU ──────────────────────────────────────────────────────
    def _generate_text_report(self, days: int, period: str) -> str:
        from datetime import datetime
        totals = self.db.get_report_summary_totals()
        subj   = self.db.get_report_by_subject(since_days=days)
        trend  = self.db.get_report_trend(since_days=min(days, 30))
        period_data = self.db.get_report_by_period(period=period, limit=20)

        lines = []
        sep   = "─" * 60

        lines.append("╔" + "═" * 58 + "╗")
        lines.append("║" + "  KPSS TAKİP — PERFORMANS RAPORU".center(58) + "║")
        lines.append("║" + f"  {datetime.now().strftime('%d.%m.%Y %H:%M')}".ljust(58) + "║")
        lines.append("╚" + "═" * 58 + "╝")
        lines.append("")

        # Genel özet
        lines.append("▶ GENEL ÖZET (Tüm Zamanlar)")
        lines.append(sep)
        lines.append(f"  Toplam Soru Çözüldü : {totals.get('total_q', 0)}")
        lines.append(f"  Toplam Doğru         : {totals.get('correct_q', 0)}")
        lines.append(f"  Genel Doğruluk       : %{totals.get('accuracy') or 0}")
        lines.append(f"  Aktif Çalışma Günü   : {totals.get('active_days', 0)}")
        lines.append(f"  Güncel Seri          : {totals.get('current_streak', 0)} gün")
        lines.append(f"  En Uzun Seri         : {totals.get('longest_streak', 0)} gün")
        lines.append("")

        # Ders bazlı
        if subj:
            lines.append(f"▶ DERS BAZLI PERFORMANS  (Son {days} Gün)")
            lines.append(sep)
            header = f"  {'Ders':<20} {'Toplam':>8} {'Doğru':>8} {'Yanlış':>8} {'Oran':>8}"
            lines.append(header)
            lines.append("  " + "-" * 54)
            for d in subj:
                acc   = d["accuracy"] or 0
                flag  = "🟢" if acc >= 70 else ("🟡" if acc >= 50 else "🔴")
                name  = d["subject"][:18]
                lines.append(
                    f"  {flag} {name:<18} {d['total'] or 0:>8} "
                    f"{d['correct'] or 0:>8} {d['wrong'] or 0:>8}  %{acc:>5}"
                )
            lines.append("")

        # Dönemsel tablo
        if period_data:
            p_label = {"daily": "GÜNLÜK", "weekly": "HAFTALIK", "monthly": "AYLIK"}
            lines.append(f"▶ {p_label.get(period, '')} DÖKÜMÜ")
            lines.append(sep)
            header = f"  {'Dönem':<16} {'Toplam':>8} {'Doğru':>8} {'Yanlış':>8} {'Oran':>8}"
            lines.append(header)
            lines.append("  " + "-" * 54)
            for d in sorted(period_data, key=lambda x: x["period_label"], reverse=True)[:20]:
                acc = d["accuracy"] or 0
                lines.append(
                    f"  {d['period_label']:<16} {d['total'] or 0:>8} "
                    f"{d['correct'] or 0:>8} {d['wrong'] or 0:>8}  %{acc:>5}"
                )
            lines.append("")

        # Trend özeti
        if trend:
            last5 = trend[-5:]
            lines.append("▶ SON 5 GÜNÜN TRENDİ")
            lines.append(sep)
            for d in last5:
                acc  = float(d["accuracy"] or 0)
                bar  = "█" * int(acc / 10) + "░" * (10 - int(acc / 10))
                lines.append(
                    f"  {d['log_date']}  [{bar}]  %{acc:>5.1f}  "
                    f"({d['total']} soru)"
                )
            lines.append("")

        lines.append("═" * 60)
        lines.append("  Rapor: KPSS Takip Uygulaması  |  kpss_tracker v3")
        return "\n".join(lines)

    # ── YARDIMCILAR ───────────────────────────────────────────────────────
    def _embed(self, parent, fig):
        canvas = FigureCanvasTkAgg(fig, master=parent)
        canvas.draw()
        w = canvas.get_tk_widget()
        w.pack(fill="x", padx=10, pady=(0, 10))

    def _no_data(self):
        no_card = Card(self._scroll)
        no_card.pack(fill="x", pady=20)
        ctk.CTkLabel(
            no_card,
            text="📭  Henüz bu aralık için veri yok.\nAnalitik sekmesinden soru girişi yapabilirsin.",
            font=ctk.CTkFont(size=13), text_color=C["subtext"]
        ).pack(pady=30)

    def _period_label(self):
        return next((l for l, v in self.PERIODS if v == self._period.get()), "")

    def _copy_to_clipboard(self, text: str):
        try:
            self.clipboard_clear()
            self.clipboard_append(text)
            self.update()
        except Exception:
            pass

    def _copy_text_report(self):
        days   = self._range.get()
        period = self._period.get()
        self._copy_to_clipboard(self._generate_text_report(days, period))


# ═══════════════════════════════════════════════════════════
# SİSTEM TRAYİ
# ═══════════════════════════════════════════════════════════
def setup_tray(app_win):
    try:
        import pystray
        from PIL import Image, ImageDraw, ImageFont
        img = Image.new("RGB", (64, 64), color="#1E1E2E")
        draw = ImageDraw.Draw(img)
        draw.ellipse([4, 4, 60, 60], fill="#89B4FA")
        draw.text((20, 16), "K", fill="#1E1E2E")

        def on_show(icon, item):
            app_win.after(0, app_win.deiconify)
            app_win.after(0, app_win.lift)

        def on_quit(icon, item):
            icon.stop()
            app_win.after(0, app_win.destroy)

        menu = pystray.Menu(
            pystray.MenuItem("Göster", on_show, default=True),
            pystray.MenuItem("Çıkış",  on_quit),
        )
        icon = pystray.Icon("kpss", img, "KPSS Takip", menu)

        def on_unmap(e):
            if app_win.wm_state() == "iconic":
                app_win.withdraw()

        app_win.bind("<Unmap>", on_unmap)
        threading.Thread(target=icon.run, daemon=True).start()
        return icon
    except ImportError:
        return None


# ═══════════════════════════════════════════════════════════
# ANA PENCERE
# ═══════════════════════════════════════════════════════════
class KPSSApp(ctk.CTk):
    PANELS = [
        ("🏠", "Dashboard",  DashboardPanel),
        ("⏱",  "Pomodoro",   PomodoroPanel),
        ("📚", "Müfredat",   CurriculumPanel),
        ("🛠",  "Yönetim",   CurriculumManagerPanel),
        ("📊", "Analitik",   AnalyticsPanel),
        ("📈", "Rapor",      RaporPanel),
        ("📅", "Takvim",     CalendarPanel),
        ("🗓",  "Plan",       HeatmapPlannerPanel),
    ]

    def __init__(self):
        super().__init__()
        self.db = DatabaseManager()
        self.title("KPSS Takip — Lisans")
        self.geometry("1160x760")
        self.minsize(940, 660)
        self.configure(fg_color=C["bg"])

        ico = ROOT / "data" / "logo.ico"
        if ico.exists():
            try:
                self.iconbitmap(str(ico))
            except Exception:
                pass

        self._active_panel: Optional[ctk.CTkFrame] = None
        self._nav_btns: list[ctk.CTkButton] = []
        self._tray = None

        self._build_layout()
        self.after(400, lambda: setattr(self, "_tray", setup_tray(self)))

        if not self.db.is_onboarding_done():
            self.after(200, self._onboarding)
        else:
            self._show_panel(0)

    # ── Layout ────────────────────────────────────────────────────────────────
    def _build_layout(self):
        sidebar = ctk.CTkFrame(self, width=64, fg_color=C["surface"],
                               corner_radius=0)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        k_lbl = ctk.CTkLabel(sidebar, text="K",
                               font=ctk.CTkFont(size=22, weight="bold"),
                               text_color=C["accent"])
        k_lbl.pack(pady=(14, 16))

        for i, (icon, label, _) in enumerate(self.PANELS):
            btn = ctk.CTkButton(sidebar, text=icon, width=46, height=46,
                                 corner_radius=10,
                                 font=ctk.CTkFont(size=20),
                                 fg_color="transparent",
                                 hover_color=C["surface2"],
                                 text_color=C["subtext"],
                                 command=lambda idx=i: self._show_panel(idx))
            btn.pack(pady=2)
            btn._tip = label  # type: ignore
            btn.bind("<Enter>", lambda e, b=btn: self._tip_show(b._tip))  # type: ignore
            btn.bind("<Leave>", lambda e: self._tip_hide())
            self._nav_btns.append(btn)

        self._tip_lbl = ctk.CTkLabel(sidebar, text="",
                                      font=ctk.CTkFont(size=9),
                                      text_color=C["subtext"],
                                      wraplength=58)
        self._tip_lbl.pack(side="bottom", pady=10)

        self._content = ctk.CTkFrame(self, fg_color="transparent")
        self._content.pack(side="left", fill="both", expand=True)

    def _tip_show(self, t):
        self._tip_lbl.configure(text=t)

    def _tip_hide(self):
        self._tip_lbl.configure(text="")

    # ── Panel switching ────────────────────────────────────────────────────────
    def _show_panel(self, idx: int):
        # Önce aktif panel güvenli yok edilir
        if self._active_panel is not None:
            try:
                self._active_panel.pack_forget()
                self._active_panel.destroy()
            except Exception:
                pass
            self._active_panel = None

        for i, btn in enumerate(self._nav_btns):
            btn.configure(
                fg_color=C["surface2"] if i == idx else "transparent",
                text_color=C["accent"]  if i == idx else C["subtext"],
            )

        _, _, PanelClass = self.PANELS[idx]
        try:
            panel = PanelClass(self._content, self.db)
            panel.pack(fill="both", expand=True, padx=14, pady=14)
            self._active_panel = panel
        except Exception as e:
            err = ctk.CTkFrame(self._content, fg_color="transparent")
            err.pack(fill="both", expand=True)
            ctk.CTkLabel(err, text=f"Panel hatası:\n{e}",
                          text_color=C["red"],
                          font=ctk.CTkFont(size=12)).pack(expand=True)
            self._active_panel = err

    def _onboarding(self):
        OnboardingWindow(self, self.db, on_done=lambda: self._show_panel(0))


# ═══════════════════════════════════════════════════════════
# GİRİŞ
# ═══════════════════════════════════════════════════════════
def run():
    app = KPSSApp()
    app.mainloop()


if __name__ == "__main__":
    run()
