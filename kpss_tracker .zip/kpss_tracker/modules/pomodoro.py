"""
modules/pomodoro.py  —  v2
Thread tabanlı Pomodoro sayacı + ses desteği.
"""
import threading
import time
import os
import struct
import wave
import tempfile
from enum import Enum, auto
from typing import Callable, Optional


class SessionState(Enum):
    IDLE        = auto()
    WORK        = auto()
    SHORT_BREAK = auto()
    LONG_BREAK  = auto()
    PAUSED      = auto()


class PomodoroTimer:
    def __init__(
        self,
        work_min: int = 25,
        short_break_min: int = 5,
        long_break_min: int = 15,
        pomodoros_per_set: int = 4,
        on_tick: Optional[Callable[[int], None]] = None,
        on_session_end: Optional[Callable[[SessionState], None]] = None,
    ):
        self.work_min          = work_min
        self.short_break_min   = short_break_min
        self.long_break_min    = long_break_min
        self.pomodoros_per_set = pomodoros_per_set
        self.on_tick           = on_tick
        self.on_session_end    = on_session_end

        self.state             = SessionState.IDLE
        self.pomodoro_count    = 0
        self._remaining        = 0
        self._thread: Optional[threading.Thread] = None
        self._stop_flag        = threading.Event()
        self._pause_flag       = threading.Event()
        self._pause_flag.set()
        self.current_session_id: Optional[int] = None
        self.elapsed_seconds   = 0

    # ── Kontrol ───────────────────────────────────
    def start_work(self):
        self._begin(SessionState.WORK, self.work_min * 60)

    def start_short_break(self):
        self._begin(SessionState.SHORT_BREAK, self.short_break_min * 60)

    def start_long_break(self):
        self._begin(SessionState.LONG_BREAK, self.long_break_min * 60)

    def pause(self):
        if self.state in (SessionState.WORK, SessionState.SHORT_BREAK, SessionState.LONG_BREAK):
            self._pause_flag.clear()
            self.state = SessionState.PAUSED

    def resume(self):
        if self.state == SessionState.PAUSED:
            self.state = SessionState.WORK
            self._pause_flag.set()

    def stop(self):
        self._stop_flag.set()
        self._pause_flag.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        self.state = SessionState.IDLE
        self.elapsed_seconds = 0

    def update_settings(self, work_min: int, short_min: int, long_min: int, per_set: int):
        """Ayarları canlı güncelle (sadece IDLE iken etkili olur)."""
        self.work_min          = work_min
        self.short_break_min   = short_min
        self.long_break_min    = long_min
        self.pomodoros_per_set = per_set

    # ── İç çalışma ────────────────────────────────
    def _begin(self, new_state: SessionState, duration_sec: int):
        self.stop()
        self._stop_flag.clear()
        self._pause_flag.set()
        self.state           = new_state
        self._remaining      = duration_sec
        self.elapsed_seconds = 0
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self):
        while self._remaining > 0 and not self._stop_flag.is_set():
            self._pause_flag.wait()
            if self._stop_flag.is_set():
                break
            time.sleep(1)
            self._remaining      -= 1
            self.elapsed_seconds += 1
            if self.on_tick:
                self.on_tick(self._remaining)
        if not self._stop_flag.is_set():
            self._on_complete()

    def _on_complete(self):
        completed_state = self.state
        if completed_state == SessionState.WORK:
            self.pomodoro_count += 1
        self.state           = SessionState.IDLE
        self.elapsed_seconds = 0
        if self.on_session_end:
            self.on_session_end(completed_state)

    # ── Yardımcı ──────────────────────────────────
    @property
    def remaining_display(self) -> str:
        m, s = divmod(self._remaining, 60)
        return f"{m:02d}:{s:02d}"

    @property
    def elapsed_minutes(self) -> int:
        return self.elapsed_seconds // 60

    def next_break_type(self) -> SessionState:
        if self.pomodoro_count > 0 and self.pomodoro_count % self.pomodoros_per_set == 0:
            return SessionState.LONG_BREAK
        return SessionState.SHORT_BREAK


# ── SES ──────────────────────────────────────────
def _generate_beep_wav(freq: int = 880, duration_ms: int = 400,
                        volume: float = 0.5) -> str:
    """Geçici bir .wav dosyası oluşturur ve yolunu döndürür."""
    sample_rate = 44100
    n_samples = int(sample_rate * duration_ms / 1000)
    import math
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    with wave.open(tmp.name, "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        frames = bytearray()
        for i in range(n_samples):
            t = i / sample_rate
            sample = int(32767 * volume * math.sin(2 * math.pi * freq * t))
            frames += struct.pack("<h", sample)
        wf.writeframes(bytes(frames))
    return tmp.name


def play_notification_sound(sound_type: str = "end", wav_path: Optional[str] = None,
                              enabled: bool = True):
    """
    sound_type: 'end' | 'break'
    wav_path: özel .wav dosyası yolu (None = otomatik oluştur)
    """
    if not enabled:
        return

    def _play():
        try:
            import winsound  # Windows
            if wav_path and os.path.exists(wav_path):
                winsound.PlaySound(wav_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
            else:
                freq = 1000 if sound_type == "end" else 600
                winsound.Beep(freq, 350)
                time.sleep(0.1)
                winsound.Beep(freq, 350)
        except ImportError:
            # Linux / macOS
            try:
                if wav_path and os.path.exists(wav_path):
                    os.system(f"aplay '{wav_path}' 2>/dev/null || afplay '{wav_path}' 2>/dev/null")
                else:
                    freq = 1000 if sound_type == "end" else 600
                    tmp = _generate_beep_wav(freq)
                    os.system(f"aplay '{tmp}' 2>/dev/null || afplay '{tmp}' 2>/dev/null")
                    os.unlink(tmp)
            except Exception:
                print("\a")

    threading.Thread(target=_play, daemon=True).start()
