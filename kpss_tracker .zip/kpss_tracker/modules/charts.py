"""
modules/charts.py
Matplotlib tabanlı grafik oluşturucu.
Tüm fonksiyonlar Figure nesnesi döndürür — UI embed edilebilir.
"""
from __future__ import annotations
import datetime
import calendar
import matplotlib
matplotlib.use("Agg")  # GUI gerektirmez; tkinter agg ile embed edilir
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from typing import Optional

# ── TEMA ──────────────────────────────────────────────────────────────────────
DARK_BG   = "#1E1E2E"
SURFACE   = "#2A2A3E"
TEXT      = "#CDD6F4"
ACCENT    = "#89B4FA"
GREEN     = "#A6E3A1"
RED       = "#F38BA8"
YELLOW    = "#F9E2AF"
MAUVE     = "#CBA6F7"
TEAL      = "#94E2D5"

SUBJECT_COLORS = {
    "Tarih":       "#C8A96E",
    "Coğrafya":    "#6EAD8B",
    "Vatandaşlık": "#8B8BC8",
    "Türkçe":      "#C87A7A",
    "Matematik":   "#7AB8C8",
}


def _apply_dark_style(ax, fig):
    fig.patch.set_facecolor(DARK_BG)
    ax.set_facecolor(SURFACE)
    ax.tick_params(colors=TEXT, labelsize=9)
    for spine in ax.spines.values():
        spine.set_color("#444466")
    ax.xaxis.label.set_color(TEXT)
    ax.yaxis.label.set_color(TEXT)
    ax.title.set_color(TEXT)


# ── HEATMAP ───────────────────────────────────────────────────────────────────
def build_heatmap(data: dict, year: int) -> plt.Figure:
    """
    GitHub tarzı yıllık aktivite ısı haritası.
    data: {date_str: intensity (0-4)}
    """
    fig, ax = plt.subplots(figsize=(14, 2.6))
    _apply_dark_style(ax, fig)

    jan1 = datetime.date(year, 1, 1)
    dec31 = datetime.date(year, 12, 31)
    start_dow = jan1.weekday()  # Pazartesi=0
    total_days = (dec31 - jan1).days + 1

    cmap_colors = ["#2A2A3E", "#3B6EA8", "#5B8DD9", "#7BAFF5", "#A8D1FF"]

    col = 0
    for day_offset in range(total_days):
        current = jan1 + datetime.timedelta(days=day_offset)
        if day_offset == 0:
            col = 0
            row = start_dow
        else:
            row = (start_dow + day_offset) % 7
            if row == 0:
                col += 1

        intensity = data.get(current.isoformat(), 0)
        color = cmap_colors[min(intensity, 4)]
        rect = mpatches.FancyBboxPatch(
            (col + 0.05, 6 - row + 0.05), 0.85, 0.85,
            boxstyle="round,pad=0.05",
            linewidth=0, facecolor=color
        )
        ax.add_patch(rect)

    total_cols = col + 1
    ax.set_xlim(-0.5, total_cols + 0.5)
    ax.set_ylim(-0.5, 7.5)

    days_tr = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"]
    ax.set_yticks(range(7))
    ax.set_yticklabels([days_tr[6 - i] for i in range(7)], fontsize=8, color=TEXT)

    # Ay etiketleri
    month_positions = {}
    for d_off in range(total_days):
        d = jan1 + datetime.timedelta(days=d_off)
        if d.day == 1:
            wk = (start_dow + d_off) // 7
            month_positions[d.month] = wk
    months_tr = ["Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu","Eyl","Eki","Kas","Ara"]
    ax.set_xticks(list(month_positions.values()))
    ax.set_xticklabels([months_tr[m-1] for m in month_positions.keys()], fontsize=8, color=TEXT)

    ax.set_title(f"{year} Çalışma Aktivitesi", color=TEXT, fontsize=11, pad=8)
    fig.tight_layout(pad=0.5)
    return fig


# ── HATA ANALİZİ BAR CHART ────────────────────────────────────────────────────
def build_error_chart(error_data: list) -> plt.Figure:
    """
    Derse göre hata tipi dağılımı (grouped bar chart).
    error_data: [{"subject", "knowledge", "attention", "time_err"}, ...]
    """
    if not error_data:
        return _empty_fig("Henüz hata verisi yok")

    subjects   = [d["subject"] for d in error_data]
    knowledge  = [d["knowledge"] or 0 for d in error_data]
    attention  = [d["attention"] or 0 for d in error_data]
    time_err   = [d["time_err"] or 0 for d in error_data]

    x = np.arange(len(subjects))
    width = 0.25

    fig, ax = plt.subplots(figsize=(8, 4))
    _apply_dark_style(ax, fig)

    b1 = ax.bar(x - width, knowledge, width, label="Bilgi Eksikliği",
                color=RED, alpha=0.85, zorder=3)
    b2 = ax.bar(x,          attention, width, label="Dikkat Hatası",
                color=YELLOW, alpha=0.85, zorder=3)
    b3 = ax.bar(x + width,  time_err,  width, label="Süre Problemi",
                color=TEAL, alpha=0.85, zorder=3)

    ax.set_xticks(x)
    ax.set_xticklabels(subjects, fontsize=9)
    ax.set_ylabel("Hata Sayısı", fontsize=9)
    ax.set_title("Derse Göre Hata Analizi", fontsize=11)
    ax.legend(facecolor=SURFACE, edgecolor="#444466", labelcolor=TEXT, fontsize=8)
    ax.yaxis.grid(True, color="#444466", alpha=0.5, zorder=0)

    # Bar değer etiketleri
    for bars in (b1, b2, b3):
        for bar in bars:
            h = bar.get_height()
            if h > 0:
                ax.text(bar.get_x() + bar.get_width() / 2, h + 0.2,
                        str(int(h)), ha="center", va="bottom",
                        fontsize=7, color=TEXT)

    fig.tight_layout()
    return fig


# ── HAFTALIK ÇALIŞMA SAATİ ────────────────────────────────────────────────────
def build_weekly_study_chart(stats: list) -> plt.Figure:
    """
    stats: [{"day": "2025-01-01", "total_min": 90, "avg_focus": 3.5}, ...]
    """
    if not stats:
        return _empty_fig("Bu hafta çalışma verisi yok")

    days  = [s["day"][-5:] for s in stats]        # MM-DD
    mins  = [s["total_min"] or 0 for s in stats]
    hours = [m / 60 for m in mins]
    focus = [s["avg_focus"] or 0 for s in stats]

    fig, ax1 = plt.subplots(figsize=(8, 3.5))
    _apply_dark_style(ax1, fig)

    bars = ax1.bar(days, hours, color=ACCENT, alpha=0.8, zorder=3)
    ax1.set_ylabel("Çalışma (saat)", fontsize=9, color=ACCENT)
    ax1.set_title("Haftalık Çalışma & Odaklanma", fontsize=11)
    ax1.yaxis.grid(True, color="#444466", alpha=0.4, zorder=0)

    # İkinci eksen: odaklanma puanı
    ax2 = ax1.twinx()
    ax2.set_facecolor(SURFACE)
    ax2.plot(days, focus, color=GREEN, marker="o", linewidth=2,
             markersize=5, label="Odak Puanı", zorder=4)
    ax2.set_ylim(0, 5)
    ax2.set_ylabel("Odak Puanı (1-5)", fontsize=9, color=GREEN)
    ax2.tick_params(colors=GREEN, labelsize=8)

    fig.tight_layout()
    return fig


# ── KONU İLERLEME PIE ─────────────────────────────────────────────────────────
def build_progress_pie(progress_by_subject: list) -> plt.Figure:
    """
    progress_by_subject: [{"name", "done", "total"}, ...]
    """
    fig, axes = plt.subplots(1, len(progress_by_subject),
                             figsize=(3 * len(progress_by_subject), 3))
    fig.patch.set_facecolor(DARK_BG)

    if len(progress_by_subject) == 1:
        axes = [axes]

    for ax, subj in zip(axes, progress_by_subject):
        done  = subj["done"]
        total = subj["total"]
        left  = total - done
        color = SUBJECT_COLORS.get(subj["name"], ACCENT)

        wedge_props = dict(width=0.45, startangle=90)
        ax.pie(
            [done, left],
            colors=[color, SURFACE],
            wedgeprops=wedge_props,
        )
        pct = round(done / total * 100) if total else 0
        ax.text(0, 0, f"%{pct}", ha="center", va="center",
                fontsize=12, fontweight="bold", color=TEXT)
        ax.set_title(subj["name"], color=TEXT, fontsize=9, pad=4)

    fig.tight_layout(pad=0.3)
    return fig


# ── YARDIMCI ──────────────────────────────────────────────────────────────────
def _empty_fig(message: str) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(6, 2))
    _apply_dark_style(ax, fig)
    ax.text(0.5, 0.5, message, transform=ax.transAxes,
            ha="center", va="center", color=TEXT, fontsize=11)
    ax.set_axis_off()
    fig.tight_layout()
    return fig


# ── RAPOR GRAFİKLERİ (v3.1) ───────────────────────────────────────────────────

def build_period_bar(data: list, period: str = "daily") -> plt.Figure:
    """
    Günlük/haftalık/aylık toplam soru ve doğruluk çift eksenli bar+line grafiği.
    data: [{"period_label", "total", "correct", "wrong", "accuracy"}, ...]
    """
    if not data:
        return _empty_fig("Henüz veri yok")

    data_sorted = sorted(data, key=lambda x: x["period_label"])
    labels   = [d["period_label"] for d in data_sorted]
    totals   = [d["total"]   or 0 for d in data_sorted]
    corrects = [d["correct"] or 0 for d in data_sorted]
    wrongs   = [d["wrong"]   or 0 for d in data_sorted]
    accuracy = [d["accuracy"] or 0 for d in data_sorted]

    period_labels_tr = {"daily": "Günlük", "weekly": "Haftalık", "monthly": "Aylık"}
    title_str = f"{period_labels_tr.get(period, period)} Soru Performansı"

    fig, ax1 = plt.subplots(figsize=(max(8, len(labels) * 0.7 + 2), 4.2))
    _apply_dark_style(ax1, fig)

    x = np.arange(len(labels))
    w = 0.38

    bars_c = ax1.bar(x - w / 2, corrects, w, label="Doğru",
                      color=GREEN, alpha=0.85, zorder=3)
    bars_w = ax1.bar(x + w / 2, wrongs,   w, label="Yanlış",
                      color=RED,   alpha=0.85, zorder=3)

    ax1.set_xticks(x)
    lbl_len = max(len(l) for l in labels)
    ax1.set_xticklabels(labels, fontsize=8, rotation=30 if lbl_len > 7 else 0,
                         ha="right" if lbl_len > 7 else "center")
    ax1.set_ylabel("Soru Sayısı", fontsize=9, color=TEXT)
    ax1.set_title(title_str, fontsize=11, color=TEXT)
    ax1.yaxis.grid(True, color="#444466", alpha=0.4, zorder=0)
    ax1.legend(facecolor=SURFACE, edgecolor="#444466", labelcolor=TEXT, fontsize=8,
                loc="upper left")

    # Toplam değer etiketi
    for bar in list(bars_c) + list(bars_w):
        h = bar.get_height()
        if h > 0:
            ax1.text(bar.get_x() + bar.get_width() / 2, h + 0.3,
                     str(int(h)), ha="center", va="bottom",
                     fontsize=7, color=TEXT)

    # Doğruluk % — sağ eksen
    ax2 = ax1.twinx()
    ax2.set_facecolor(SURFACE)
    ax2.plot(x, accuracy, color=ACCENT, marker="o", linewidth=2,
              markersize=5, zorder=5, label="Doğruluk %")
    ax2.set_ylim(0, 110)
    ax2.set_ylabel("Doğruluk %", fontsize=9, color=ACCENT)
    ax2.tick_params(colors=ACCENT, labelsize=8)

    fig.tight_layout()
    return fig


def build_subject_radar(data: list) -> plt.Figure:
    """
    Derse göre doğruluk yüzdesi radar / spider chart.
    data: [{"subject", "accuracy"}, ...]
    """
    subjects  = [d["subject"] for d in data]
    accuracies = [float(d["accuracy"] or 0) for d in data]

    if len(subjects) < 3:
        return build_subject_bar(data)

    N     = len(subjects)
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]
    vals   = accuracies + accuracies[:1]

    fig, ax = plt.subplots(figsize=(5, 5), subplot_kw=dict(polar=True))
    fig.patch.set_facecolor(DARK_BG)
    ax.set_facecolor(SURFACE)

    ax.plot(angles, vals, color=ACCENT, linewidth=2, linestyle="solid")
    ax.fill(angles, vals, color=ACCENT, alpha=0.25)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(subjects, fontsize=10, color=TEXT)
    ax.set_ylim(0, 100)
    ax.set_yticks([25, 50, 75, 100])
    ax.set_yticklabels(["25%", "50%", "75%", "100%"], fontsize=7, color=MAUVE)
    ax.tick_params(colors=TEXT)
    ax.spines["polar"].set_color("#444466")
    ax.grid(color="#444466", alpha=0.5)
    ax.set_title("Derse Göre Doğruluk (Radar)", fontsize=11,
                  color=TEXT, pad=16)

    fig.tight_layout()
    return fig


def build_subject_bar(data: list) -> plt.Figure:
    """Derse göre yatay bar — soru sayısı + doğruluk."""
    if not data:
        return _empty_fig("Veri yok")

    subjects  = [f"{d.get('icon','')}{d['subject']}" for d in data]
    totals    = [d["total"]    or 0 for d in data]
    accuracy  = [d["accuracy"] or 0 for d in data]
    colors    = [SUBJECT_COLORS.get(d["subject"], ACCENT) for d in data]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, max(3, len(subjects) * 0.7 + 1.5)))
    fig.patch.set_facecolor(DARK_BG)

    # Sol: toplam soru (yatay bar)
    ax1.set_facecolor(SURFACE)
    bars = ax1.barh(subjects, totals, color=colors, alpha=0.85, zorder=3)
    ax1.set_xlabel("Toplam Soru", fontsize=9, color=TEXT)
    ax1.set_title("Çözülen Soru", fontsize=11, color=TEXT)
    for spine in ax1.spines.values():
        spine.set_color("#444466")
    ax1.tick_params(colors=TEXT, labelsize=9)
    ax1.xaxis.grid(True, color="#444466", alpha=0.4, zorder=0)
    for bar in bars:
        w = bar.get_width()
        if w > 0:
            ax1.text(w + 0.5, bar.get_y() + bar.get_height() / 2,
                     str(int(w)), va="center", fontsize=8, color=TEXT)

    # Sağ: doğruluk % (yatay bar)
    ax2.set_facecolor(SURFACE)
    acc_colors = [GREEN if a >= 70 else (YELLOW if a >= 50 else RED) for a in accuracy]
    ax2.barh(subjects, accuracy, color=acc_colors, alpha=0.85, zorder=3)
    ax2.set_xlim(0, 105)
    ax2.set_xlabel("Doğruluk %", fontsize=9, color=TEXT)
    ax2.set_title("Doğruluk Oranı", fontsize=11, color=TEXT)
    ax2.axvline(70, color=GREEN, linewidth=1, linestyle="--", alpha=0.6,
                 label="Hedef %70")
    for spine in ax2.spines.values():
        spine.set_color("#444466")
    ax2.tick_params(colors=TEXT, labelsize=9)
    ax2.xaxis.grid(True, color="#444466", alpha=0.4, zorder=0)
    ax2.legend(facecolor=SURFACE, edgecolor="#444466", labelcolor=TEXT, fontsize=7)

    fig.tight_layout(pad=2)
    return fig


def build_topic_treemap(data: list) -> plt.Figure:
    """
    Konu bazlı doğruluk — renkli tablo/heatmap (matplotlib treemap yok,
    custom ısı-tablosu kullanıyoruz).
    data: [{"subject","topic","total","accuracy"}, ...]
    """
    if not data:
        return _empty_fig("Konu verisi yok")

    # En fazla 20 konu göster
    data = sorted(data, key=lambda x: x["total"] or 0, reverse=True)[:20]

    topics    = [f"{d['subject'][:4]}›{d['topic'][:16]}" for d in data]
    totals    = [d["total"]    or 0 for d in data]
    accuracy  = [float(d["accuracy"] or 0) for d in data]

    fig, ax = plt.subplots(figsize=(9, max(4, len(topics) * 0.45 + 1.5)))
    _apply_dark_style(ax, fig)

    y = np.arange(len(topics))

    # Arkada toplam soru (gri)
    ax.barh(y, totals, color="#3A3A5C", alpha=0.6, zorder=2, label="Toplam")

    # Önde doğru (renk doğruluğa göre)
    corrects = [int(d["total"] * d["accuracy"] / 100) for d in data]
    bar_colors = [GREEN if a >= 70 else (YELLOW if a >= 50 else RED) for a in accuracy]
    ax.barh(y, corrects, color=bar_colors, alpha=0.85, zorder=3, label="Doğru")

    ax.set_yticks(y)
    ax.set_yticklabels(topics, fontsize=8)
    ax.set_xlabel("Soru Sayısı", fontsize=9, color=TEXT)
    ax.set_title("Konu Bazlı Performans  (🟢≥70%  🟡≥50%  🔴<50%)",
                  fontsize=10, color=TEXT)
    ax.xaxis.grid(True, color="#444466", alpha=0.4, zorder=0)

    # Doğruluk etiketi
    for i, (t, a) in enumerate(zip(totals, accuracy)):
        ax.text(t + 0.3, i, f"%{a:.0f}", va="center", fontsize=7, color=TEXT)

    ax.legend(facecolor=SURFACE, edgecolor="#444466", labelcolor=TEXT,
               fontsize=8, loc="lower right")
    fig.tight_layout()
    return fig


def build_accuracy_trend(data: list) -> plt.Figure:
    """
    Günlük doğruluk trendi çizgi grafiği + hareketli ortalama.
    data: [{"log_date","total","correct","accuracy"}, ...]
    """
    if not data:
        return _empty_fig("Trend verisi yok")

    dates    = [d["log_date"][-5:] for d in data]   # MM-DD
    accuracy = [float(d["accuracy"] or 0) for d in data]
    totals   = [d["total"] or 0 for d in data]

    fig, ax1 = plt.subplots(figsize=(9, 3.8))
    _apply_dark_style(ax1, fig)

    x = np.arange(len(dates))

    # Bar: günlük soru sayısı (arka plan)
    ax1.bar(x, totals, color="#3A3A5C", alpha=0.5, zorder=2, label="Soru Sayısı")
    ax1.set_ylabel("Soru Sayısı", fontsize=9, color="#5A5A8A")
    ax1.tick_params(axis="y", colors="#5A5A8A", labelsize=8)

    ax2 = ax1.twinx()
    ax2.set_facecolor(SURFACE)

    # Doğruluk çizgisi
    ax2.plot(x, accuracy, color=ACCENT, linewidth=2.5, marker="o",
              markersize=4, zorder=5, label="Günlük %")

    # 3 günlük hareketli ortalama
    if len(accuracy) >= 3:
        ma = np.convolve(accuracy, np.ones(3) / 3, mode="valid")
        ax2.plot(np.arange(2, len(accuracy)), ma, color=GREEN, linewidth=1.5,
                  linestyle="--", alpha=0.8, label="3G Ort.")

    ax2.axhline(70, color=GREEN, linewidth=1, linestyle=":", alpha=0.5)
    ax2.set_ylim(0, 110)
    ax2.set_ylabel("Doğruluk %", fontsize=9, color=ACCENT)
    ax2.tick_params(colors=ACCENT, labelsize=8)

    ax1.set_xticks(x)
    ax1.set_xticklabels(dates, fontsize=8,
                         rotation=30 if len(dates) > 10 else 0,
                         ha="right" if len(dates) > 10 else "center")
    ax1.set_title("Doğruluk Trendi", fontsize=11, color=TEXT)

    # Legend birleştir
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax2.legend(h1 + h2, l1 + l2, facecolor=SURFACE,
                edgecolor="#444466", labelcolor=TEXT, fontsize=8)

    fig.tight_layout()
    return fig


def build_error_breakdown_pie(data: list) -> plt.Figure:
    """Hata tipi pasta grafiği (tüm dersler toplam)."""
    if not data:
        return _empty_fig("Hata verisi yok")

    total_k = sum(d.get("err_k", 0) or 0 for d in data)
    total_a = sum(d.get("err_a", 0) or 0 for d in data)
    total_t = sum(d.get("err_t", 0) or 0 for d in data)

    vals   = [total_k, total_a, total_t]
    labels = ["Bilgi Eksikliği", "Dikkat Hatası", "Süre Problemi"]
    colors = [RED, YELLOW, TEAL]

    non_zero = [(v, l, c) for v, l, c in zip(vals, labels, colors) if v > 0]
    if not non_zero:
        return _empty_fig("Hata kaydı yok")

    vals, labels, colors = zip(*non_zero)

    fig, ax = plt.subplots(figsize=(5.5, 4))
    fig.patch.set_facecolor(DARK_BG)
    ax.set_facecolor(DARK_BG)

    wedges, texts, autotexts = ax.pie(
        vals,
        labels=labels,
        colors=colors,
        autopct="%1.1f%%",
        startangle=90,
        pctdistance=0.75,
        wedgeprops=dict(width=0.55),  # donut
    )
    for t in texts:
        t.set_color(TEXT)
        t.set_fontsize(10)
    for at in autotexts:
        at.set_color(DARK_BG)
        at.set_fontsize(9)
        at.set_fontweight("bold")

    ax.set_title("Hata Tipi Dağılımı", fontsize=11, color=TEXT, pad=10)
    fig.tight_layout()
    return fig
