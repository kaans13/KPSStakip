"""
main.py  —  KPSS Takip Uygulaması giriş noktası
PyInstaller ile paketlendiğinde sys._MEIPASS üzerinden
veri dosyalarını doğru konumdan okur.
"""
# main.py başında bunu dene
import ui.app
import database.db_manager
import modules.pomodoro
import modules.charts
import sys
import os
from pathlib import Path


def get_base_path() -> Path:
    """
    PyInstaller EXE içinde çalışıyorsa geçici _MEIPASS klasörünü,
    normal Python çalışmasında script klasörünü döndürür.
    """
    if getattr(sys, 'frozen', False):
        # EXE modunda: PyInstaller tüm dosyaları buraya açar
        return Path(sys._MEIPASS)
    else:
        return Path(__file__).parent


def get_data_path() -> Path:
    """
    Kullanıcı verisi (SQLite DB) için yazılabilir klasör.
    EXE modunda: exe'nin yanındaki klasör (AppData değil — taşınabilir).
    """
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent / "kpss_data"
    else:
        return Path(__file__).parent / "data"


def check_dependencies():
    """Normal Python modunda bağımlılık kontrolü."""
    if getattr(sys, 'frozen', False):
        return  # EXE içinde zaten her şey var
    required = ["customtkinter", "matplotlib", "numpy"]
    missing = []
    for pkg in required:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    if missing:
        print("Eksik paketler — terminalde şunu çalıştır:")
        print(f"  pip install {' '.join(missing)}")
        sys.exit(1)


if __name__ == "__main__":
    check_dependencies()

    # PATH ayarla — PyInstaller EXE için gerekli
    base = get_base_path()
    data = get_data_path()
    sys.path.insert(0, str(base))

    # DB ve şema yollarını ortam değişkeni ile geç
    os.environ["KPSS_BASE_PATH"] = str(base)
    os.environ["KPSS_DATA_PATH"] = str(data)

    from ui.app import run
    run()
