@echo off
echo [+] Eski dosyalar temizleniyor...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

echo [+] Gerekli kutuphaneler yukleniyor...
pip install pyinstaller customtkinter matplotlib numpy pillow tkcalendar pystray babel

echo [+] EXE Olusturuluyor (Modul yollari cozuluyor)...
pyinstaller --noconfirm --onedir --windowed ^
--paths "." ^
--name "KPSS_Takip_Sistemi" ^
--add-data "data/curriculum.json;data" ^
--add-data "database/schema.sql;database" ^
--hidden-import "ui" ^
--hidden-import "ui.app" ^
--hidden-import "database" ^
--hidden-import "database.db_manager" ^
--hidden-import "modules" ^
--hidden-import "modules.pomodoro" ^
--hidden-import "modules.charts" ^
--collect-all "customtkinter" ^
--collect-all "tkcalendar" ^
--collect-all "babel" ^
main.py

echo [!] ISLEM TAMAM! 'dist/KPSS_Takip_Sistemi' klasorunu acip test edebilirsin.
pause