"""
database/db_manager.py  —  v3
Kalıcı WAL modu, threading.Lock, tek bağlantı mimarisi.

Temel fix: Tüm yazma işlemleri _execute() üzerinden gider.
mark_topic_complete içinde _update_activity_log artık AYNI
bağlantıyı (conn) parametre olarak alır — iç içe bağlantı yok.
"""
import sqlite3
import json
import threading
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict
import sys
import os
from pathlib import Path

import os as _os
def get_resource_path(relative_path):
    """ EXE içindeki geçici klasörü veya geliştirme klasörünü bulur. """
    if hasattr(sys, '_MEIPASS'):
        return Path(sys._MEIPASS) / relative_path
    return Path(__file__).parent.parent / relative_path

# 1. Sabit Veriler (Müfredat ve Şema) - Bunlar EXE'nin içine gömülür
SCHEMA_PATH     = get_resource_path("database/schema.sql")
CURRICULUM_PATH = get_resource_path("data/curriculum.json")

# 2. Kullanıcı Verisi (Veritabanı) - Bu Bilgisayarda Kalıcı Olmalı
# Eğer veritabanını programın yanına koyarsan, arkadaşın yeni sürümü yüklediğinde eski verileri silinir.
# Bu yüzden Windows'un standart uygulama veri klasörüne (AppData) kaydediyoruz.
APP_DATA_DIR = Path(os.getenv('APPDATA')) / "KPSS_Takip_Sistemi"
APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = APP_DATA_DIR / "kpss_tracker.db"

def _resolve_paths():
    """PyInstaller EXE ve normal Python modu için doğru yolları döndürür."""
    import sys
    if _base := _os.environ.get("KPSS_BASE_PATH"):
        base = Path(_base)
    elif getattr(sys, 'frozen', False):
        base = Path(sys._MEIPASS)
    else:
        base = Path(__file__).parent.parent

    if _data := _os.environ.get("KPSS_DATA_PATH"):
        data = Path(_data)
    else:
        data = base / "data"

    data.mkdir(parents=True, exist_ok=True)
    return (
        data / "kpss_tracker.db",
        base / "database" / "schema.sql",
        base / "data" / "curriculum.json",
    )

DB_PATH, SCHEMA_PATH, CURRICULUM_PATH = _resolve_paths()


class DatabaseManager:

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()   # tek yazma kilidi
        self._init_db()

    # ──────────────────────────────────────────────
    # BAĞLANTI — WAL modu + timeout
    # ──────────────────────────────────────────────
    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=20,
                               check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        return conn

    def _init_db(self):
        with self._lock:
            conn = self._conn()
            try:
                if SCHEMA_PATH.exists():
                    conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
                if conn.execute("SELECT COUNT(*) FROM subjects").fetchone()[0] == 0:
                    self._seed_curriculum(conn)
                conn.commit()
            finally:
                conn.close()

    # ──────────────────────────────────────────────
    # MÜFREDAт SEED
    # ──────────────────────────────────────────────
    def _seed_curriculum(self, conn: sqlite3.Connection):
        if not CURRICULUM_PATH.exists():
            return
        data = json.loads(CURRICULUM_PATH.read_text(encoding="utf-8"))
        for subj in data["subjects"]:
            conn.execute(
                "INSERT OR IGNORE INTO subjects (name, icon, color_hex) VALUES (?,?,?)",
                (subj["name"], subj["icon"], subj["color_hex"]),
            )
            sid = conn.execute(
                "SELECT id FROM subjects WHERE name=?", (subj["name"],)
            ).fetchone()["id"]
            self._insert_topics_rec(conn, sid, subj["topics"], None, 0)

    def _insert_topics_rec(self, conn, sid, topics, parent_id, order):
        for i, t in enumerate(topics):
            conn.execute(
                "INSERT INTO topics (subject_id,parent_id,title,order_index) VALUES(?,?,?,?)",
                (sid, parent_id, t["title"], order + i),
            )
            tid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            if t.get("children"):
                self._insert_topics_rec(conn, sid, t["children"], tid, 0)

    # ──────────────────────────────────────────────
    # ONBOARDING
    # ──────────────────────────────────────────────
    def is_onboarding_done(self) -> bool:
        return self.get_setting("onboarding_done", "0") == "1"

    def complete_onboarding(self, user_name: str):
        self.set_setting("user_name", user_name.strip())
        self.set_setting("onboarding_done", "1")

    def get_user_name(self) -> str:
        return self.get_setting("user_name", "Öğrenci")

    # ──────────────────────────────────────────────
    # DERSLER (CRUD)
    # ──────────────────────────────────────────────
    def get_subjects(self) -> List[Dict]:
        conn = self._conn()
        try:
            rows = conn.execute("SELECT * FROM subjects ORDER BY id").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def add_subject(self, name: str, icon: str = "📚",
                    color_hex: str = "#6C8EBF") -> int:
        with self._lock:
            conn = self._conn()
            try:
                conn.execute(
                    "INSERT INTO subjects (name,icon,color_hex) VALUES (?,?,?)",
                    (name.strip(), icon, color_hex),
                )
                rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                conn.commit()
                return rid
            finally:
                conn.close()

    def update_subject(self, sid: int, name: str, icon: str, color_hex: str):
        with self._lock:
            conn = self._conn()
            try:
                conn.execute(
                    "UPDATE subjects SET name=?,icon=?,color_hex=? WHERE id=?",
                    (name.strip(), icon, color_hex, sid),
                )
                conn.commit()
            finally:
                conn.close()

    def delete_subject(self, sid: int):
        with self._lock:
            conn = self._conn()
            try:
                conn.execute("DELETE FROM subjects WHERE id=?", (sid,))
                conn.commit()
            finally:
                conn.close()

    # ──────────────────────────────────────────────
    # KONULAR (CRUD)
    # ──────────────────────────────────────────────
    def get_topics_flat(self, subject_id: int) -> List[Dict]:
        """Sadece yaprak konular (soru girişi için)."""
        conn = self._conn()
        try:
            rows = conn.execute(
                """SELECT t.* FROM topics t
                   WHERE t.subject_id=?
                     AND t.id NOT IN (
                         SELECT DISTINCT parent_id FROM topics
                         WHERE parent_id IS NOT NULL
                     )
                   ORDER BY t.order_index, t.title""",
                (subject_id,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_topics_all(self, subject_id: int) -> List[Dict]:
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT * FROM topics WHERE subject_id=? ORDER BY order_index,title",
                (subject_id,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_topics_tree(self, subject_id: int) -> List[Dict]:
        items = self.get_topics_all(subject_id)
        return self._build_tree(items)

    def _build_tree(self, items: List[Dict], parent_id=None) -> List[Dict]:
        return [
            {**item, "children": self._build_tree(items, item["id"])}
            for item in items
            if item["parent_id"] == parent_id
        ]

    def add_topic(self, subject_id: int, title: str,
                  parent_id: Optional[int] = None) -> int:
        with self._lock:
            conn = self._conn()
            try:
                conn.execute(
                    "INSERT INTO topics (subject_id,parent_id,title) VALUES(?,?,?)",
                    (subject_id, parent_id, title.strip()),
                )
                rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                conn.commit()
                return rid
            finally:
                conn.close()

    def update_topic(self, topic_id: int, title: str):
        with self._lock:
            conn = self._conn()
            try:
                conn.execute("UPDATE topics SET title=? WHERE id=?",
                             (title.strip(), topic_id))
                conn.commit()
            finally:
                conn.close()

    def delete_topic(self, topic_id: int):
        with self._lock:
            conn = self._conn()
            try:
                conn.execute("DELETE FROM topics WHERE id=?", (topic_id,))
                conn.commit()
            finally:
                conn.close()

    def mark_topic_complete(self, topic_id: int, completed: bool = True):
        """
        FIX: _update_activity_log aynı conn üzerinde çağrılıyor.
        İki ayrı bağlantı açılmadığı için database is locked hatası yok.
        """
        today = date.today()
        with self._lock:
            conn = self._conn()
            try:
                if completed:
                    conn.execute(
                        """UPDATE topics SET
                            is_completed=1, completed_at=?,
                            review_1day=?, review_7day=?, review_30day=?
                           WHERE id=?""",
                        (
                            today.isoformat(),
                            (today + timedelta(days=1)).isoformat(),
                            (today + timedelta(days=7)).isoformat(),
                            (today + timedelta(days=30)).isoformat(),
                            topic_id,
                        ),
                    )
                    # Aynı conn ile activity log — kilitlenme yok
                    self._upsert_activity(conn, today, extra_topics=1)
                else:
                    conn.execute(
                        """UPDATE topics SET
                            is_completed=0, completed_at=NULL,
                            review_1day=NULL, review_7day=NULL, review_30day=NULL
                           WHERE id=?""",
                        (topic_id,),
                    )
                conn.commit()
            finally:
                conn.close()

    def get_progress(self, subject_id: Optional[int] = None) -> Dict:
        conn = self._conn()
        try:
            if subject_id:
                total = conn.execute(
                    "SELECT COUNT(*) FROM topics WHERE subject_id=?",
                    (subject_id,)
                ).fetchone()[0]
                done = conn.execute(
                    "SELECT COUNT(*) FROM topics WHERE subject_id=? AND is_completed=1",
                    (subject_id,)
                ).fetchone()[0]
            else:
                total = conn.execute(
                    "SELECT COUNT(*) FROM topics WHERE parent_id IS NOT NULL"
                ).fetchone()[0]
                done = conn.execute(
                    "SELECT COUNT(*) FROM topics WHERE is_completed=1"
                ).fetchone()[0]
        finally:
            conn.close()
        return {"total": total, "done": done,
                "pct": round(done / total * 100, 1) if total else 0.0}

    # ──────────────────────────────────────────────
    # ETA
    # ──────────────────────────────────────────────
    def calculate_eta(self) -> Optional[date]:
        prog = self.get_progress()
        remaining = prog["total"] - prog["done"]
        if remaining <= 0:
            return date.today()
        week_ago = (date.today() - timedelta(days=7)).isoformat()
        conn = self._conn()
        try:
            completed_week = conn.execute(
                "SELECT COUNT(*) FROM topics WHERE completed_at >= ?", (week_ago,)
            ).fetchone()[0]
        finally:
            conn.close()
        if completed_week == 0:
            return None
        rate = completed_week / 7.0
        return date.today() + timedelta(days=int(remaining / rate))

    # ──────────────────────────────────────────────
    # SPACED REPETITION
    # ──────────────────────────────────────────────
    def get_todays_reviews(self) -> List[Dict]:
        today = date.today().isoformat()
        conn = self._conn()
        try:
            rows = conn.execute(
                """SELECT t.*, s.name as subject_name, s.icon as subject_icon
                   FROM topics t JOIN subjects s ON t.subject_id=s.id
                   WHERE t.review_1day=? OR t.review_7day=? OR t.review_30day=?
                   ORDER BY s.id""",
                (today, today, today),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def mark_review_done(self, topic_id: int, review_type: str):
        col_map = {
            "1day": "review_1day",
            "7day": "review_7day",
            "30day": "review_30day",
        }
        col = col_map.get(review_type)
        if not col:
            return
        with self._lock:
            conn = self._conn()
            try:
                conn.execute(f"UPDATE topics SET {col}=NULL WHERE id=?",
                             (topic_id,))
                conn.commit()
            finally:
                conn.close()

    # ──────────────────────────────────────────────
    # POMODORO
    # ──────────────────────────────────────────────
    def start_pomodoro(self, topic_id: Optional[int],
                       subject_id: Optional[int],
                       duration_min: int = 25) -> int:
        with self._lock:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO pomodoro_sessions
                       (topic_id,subject_id,started_at,duration_min,session_type)
                       VALUES (?,?,?,?,'work')""",
                    (topic_id, subject_id,
                     datetime.now().isoformat(), duration_min),
                )
                rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                conn.commit()
                return rid
            finally:
                conn.close()

    def finish_pomodoro(self, session_id: int, actual_min: int,
                        focus_score: int, completed: bool = True):
        with self._lock:
            conn = self._conn()
            try:
                conn.execute(
                    """UPDATE pomodoro_sessions
                       SET ended_at=?,actual_min=?,focus_score=?,completed=?
                       WHERE id=?""",
                    (datetime.now().isoformat(), actual_min,
                     focus_score, int(completed), session_id),
                )
                if actual_min > 0:
                    self._upsert_activity(conn, date.today(),
                                          extra_minutes=actual_min,
                                          extra_pomodoros=1 if completed else 0)
                conn.commit()
            finally:
                conn.close()

    def get_study_stats(self, days: int = 7) -> List[Dict]:
        since = (date.today() - timedelta(days=days)).isoformat()
        conn = self._conn()
        try:
            rows = conn.execute(
                """SELECT date(started_at) as day,
                          COALESCE(SUM(actual_min),0) as total_min,
                          COUNT(*) as sessions,
                          COALESCE(AVG(focus_score),0.0) as avg_focus
                   FROM pomodoro_sessions
                   WHERE started_at >= ? AND completed=1
                   GROUP BY day ORDER BY day""",
                (since,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ──────────────────────────────────────────────
    # SORU ANALİTİĞİ
    # ──────────────────────────────────────────────
    def log_questions(self, subject_id: int, topic_id: int,
                      total: int, correct: int,
                      err_knowledge: int = 0,
                      err_attention: int = 0,
                      err_time: int = 0):
        if total <= 0:
            raise ValueError("Soru sayısı 0'dan büyük olmalı.")
        if not (0 <= correct <= total):
            raise ValueError("Doğru sayısı geçersiz.")
        today = date.today().isoformat()
        with self._lock:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO daily_questions
                       (log_date,subject_id,topic_id,total_solved,correct_count,
                        err_knowledge,err_attention,err_time)
                       VALUES (?,?,?,?,?,?,?,?)""",
                    (today, subject_id, topic_id, total, correct,
                     err_knowledge, err_attention, err_time),
                )
                self._upsert_activity(conn, date.today(),
                                      extra_questions=total)
                conn.commit()
            finally:
                conn.close()

    def get_error_analysis(self) -> List[Dict]:
        conn = self._conn()
        try:
            rows = conn.execute(
                """SELECT s.name as subject,
                          COALESCE(SUM(dq.err_knowledge),0) as knowledge,
                          COALESCE(SUM(dq.err_attention),0) as attention,
                          COALESCE(SUM(dq.err_time),0)      as time_err
                   FROM daily_questions dq
                   JOIN subjects s ON dq.subject_id=s.id
                   GROUP BY dq.subject_id""",
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_daily_accuracy(self, days: int = 7) -> List[Dict]:
        since = (date.today() - timedelta(days=days)).isoformat()
        conn = self._conn()
        try:
            rows = conn.execute(
                """SELECT log_date,
                          SUM(total_solved) as total,
                          SUM(correct_count) as correct
                   FROM daily_questions WHERE log_date>=?
                   GROUP BY log_date ORDER BY log_date""",
                (since,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ──────────────────────────────────────────────
    # TAKVİM
    # ──────────────────────────────────────────────
    def get_day_summary(self, target_date: date) -> Dict:
        d = target_date.isoformat()
        conn = self._conn()
        try:
            q = conn.execute(
                """SELECT COALESCE(SUM(total_solved),0)  as total_q,
                          COALESCE(SUM(correct_count),0) as correct_q
                   FROM daily_questions WHERE log_date=?""",
                (d,),
            ).fetchone()
            p = conn.execute(
                """SELECT COALESCE(SUM(actual_min),0) as study_min,
                          COUNT(*)                    as pomo_count
                   FROM pomodoro_sessions
                   WHERE date(started_at)=? AND completed=1""",
                (d,),
            ).fetchone()
            t = conn.execute(
                "SELECT COUNT(*) as topics_done FROM topics WHERE date(completed_at)=?",
                (d,),
            ).fetchone()

            # Konu bazlı soru dağılımı
            detail_rows = conn.execute(
                """SELECT tp.title as topic, s.name as subject,
                          SUM(dq.total_solved) as total,
                          SUM(dq.correct_count) as correct
                   FROM daily_questions dq
                   JOIN topics tp ON dq.topic_id=tp.id
                   JOIN subjects s ON dq.subject_id=s.id
                   WHERE dq.log_date=?
                   GROUP BY dq.topic_id
                   ORDER BY total DESC""",
                (d,),
            ).fetchall()
        finally:
            conn.close()

        return {
            "date": d,
            "total_questions":   q["total_q"],
            "correct_questions": q["correct_q"],
            "study_minutes":     p["study_min"],
            "pomodoros":         p["pomo_count"],
            "topics_completed":  t["topics_done"],
            "topic_detail":      [dict(r) for r in detail_rows],
        }

    # ──────────────────────────────────────────────
    # PLANLAYICI
    # ──────────────────────────────────────────────
    def save_plan(self, plan_date: date, target_topics: list,
                  target_questions: int, target_study_min: int,
                  notes: str = ""):
        with self._lock:
            conn = self._conn()
            try:
                conn.execute(
                    """INSERT INTO daily_plans
                       (plan_date,target_topics,target_questions,target_study_min,notes)
                       VALUES(?,?,?,?,?)
                       ON CONFLICT(plan_date) DO UPDATE SET
                       target_topics=excluded.target_topics,
                       target_questions=excluded.target_questions,
                       target_study_min=excluded.target_study_min,
                       notes=excluded.notes,
                       updated_at=CURRENT_TIMESTAMP""",
                    (plan_date.isoformat(), json.dumps(target_topics),
                     target_questions, target_study_min, notes),
                )
                conn.commit()
            finally:
                conn.close()

    def get_plan(self, plan_date: date) -> Optional[Dict]:
        conn = self._conn()
        try:
            row = conn.execute(
                "SELECT * FROM daily_plans WHERE plan_date=?",
                (plan_date.isoformat(),),
            ).fetchone()
        finally:
            conn.close()
        if not row:
            return None
        d = dict(row)
        d["target_topics"] = json.loads(d.get("target_topics") or "[]")
        d["actual_topics"]  = json.loads(d.get("actual_topics")  or "[]")
        return d

    def get_plan_completion(self, plan_date: date) -> Dict:
        plan = self.get_plan(plan_date)
        if not plan:
            return {"study_pct": 0, "question_pct": 0}
        summary = self.get_day_summary(plan_date)
        s_pct = (min(100, round(summary["study_minutes"] /
                                plan["target_study_min"] * 100))
                 if plan["target_study_min"] > 0 else 0)
        q_pct = (min(100, round(summary["total_questions"] /
                                plan["target_questions"] * 100))
                 if plan["target_questions"] > 0 else 0)
        return {"study_pct": s_pct, "question_pct": q_pct}

    # ──────────────────────────────────────────────
    # AKTİVİTE LOG  (FIX: conn parametre alır)
    # ──────────────────────────────────────────────
    def _upsert_activity(self, conn: sqlite3.Connection,
                          log_date: date,
                          extra_minutes: int = 0,
                          extra_questions: int = 0,
                          extra_pomodoros: int = 0,
                          extra_topics: int = 0):
        """Mevcut açık bağlantı üzerinde activity_log günceller — kilitlenme yok."""
        conn.execute(
            """INSERT INTO activity_log
               (log_date,study_minutes,questions_solved,pomodoros_done,topics_completed)
               VALUES(?,?,?,?,?)
               ON CONFLICT(log_date) DO UPDATE SET
               study_minutes    = study_minutes    + excluded.study_minutes,
               questions_solved = questions_solved + excluded.questions_solved,
               pomodoros_done   = pomodoros_done   + excluded.pomodoros_done,
               topics_completed = topics_completed + excluded.topics_completed""",
            (log_date.isoformat(), extra_minutes, extra_questions,
             extra_pomodoros, extra_topics),
        )

    # Genel aktivite log (dışarıdan çağrılabilir)
    def update_activity_log(self, log_date: date, **kwargs):
        with self._lock:
            conn = self._conn()
            try:
                self._upsert_activity(conn, log_date, **kwargs)
                conn.commit()
            finally:
                conn.close()

    def get_heatmap_data(self, year: int) -> Dict:
        conn = self._conn()
        try:
            rows = conn.execute(
                """SELECT log_date, study_minutes FROM activity_log
                   WHERE strftime('%Y',log_date)=?""",
                (str(year),),
            ).fetchall()
        finally:
            conn.close()
        result = {}
        for r in rows:
            mins = r["study_minutes"] or 0
            result[r["log_date"]] = min(4, mins // 60 if mins >= 60 else
                                         (1 if mins > 0 else 0))
        return result

    # ──────────────────────────────────────────────
    # AYARLAR
    # ──────────────────────────────────────────────
    def get_setting(self, key: str, default: str = "") -> str:
        conn = self._conn()
        try:
            row = conn.execute(
                "SELECT value FROM settings WHERE key=?", (key,)
            ).fetchone()
            return row["value"] if row else default
        finally:
            conn.close()

    def set_setting(self, key: str, value: str):
        with self._lock:
            conn = self._conn()
            try:
                conn.execute(
                    "INSERT INTO settings(key,value) VALUES(?,?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, str(value)),
                )
                conn.commit()
            finally:
                conn.close()

    # ──────────────────────────────────────────────
    # RAPOR SORGULARI (v3.1)
    # ──────────────────────────────────────────────

    def get_report_by_period(self, period: str = "daily",
                              limit: int = 30) -> List[Dict]:
        """
        period: 'daily' | 'weekly' | 'monthly'
        Her dönem için: toplam soru, doğru, yanlış, net, doğruluk yüzdesi.
        """
        conn = self._conn()
        try:
            if period == "daily":
                group_expr = "log_date"
                label_expr = "log_date"
            elif period == "weekly":
                # ISO hafta: 2025-W03
                group_expr = "strftime('%Y-W%W', log_date)"
                label_expr = "strftime('%Y-W%W', log_date)"
            else:  # monthly
                group_expr = "strftime('%Y-%m', log_date)"
                label_expr = "strftime('%Y-%m', log_date)"

            rows = conn.execute(
                f"""SELECT {label_expr} as period_label,
                           SUM(total_solved)  as total,
                           SUM(correct_count) as correct,
                           SUM(total_solved - correct_count) as wrong,
                           ROUND(SUM(correct_count)*100.0 /
                                 NULLIF(SUM(total_solved),0), 1) as accuracy
                    FROM daily_questions
                    GROUP BY {group_expr}
                    ORDER BY period_label DESC
                    LIMIT ?""",
                (limit,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_report_by_subject(self, since_days: int = 30) -> List[Dict]:
        """Derse göre performans özeti."""
        since = (date.today() - timedelta(days=since_days)).isoformat()
        conn = self._conn()
        try:
            rows = conn.execute(
                """SELECT s.name as subject, s.icon,
                          SUM(dq.total_solved)  as total,
                          SUM(dq.correct_count) as correct,
                          SUM(dq.total_solved - dq.correct_count) as wrong,
                          ROUND(SUM(dq.correct_count)*100.0 /
                                NULLIF(SUM(dq.total_solved),0), 1) as accuracy,
                          COALESCE(SUM(dq.err_knowledge),0) as err_k,
                          COALESCE(SUM(dq.err_attention),0) as err_a,
                          COALESCE(SUM(dq.err_time),0)      as err_t
                   FROM daily_questions dq
                   JOIN subjects s ON dq.subject_id=s.id
                   WHERE dq.log_date >= ?
                   GROUP BY dq.subject_id
                   ORDER BY total DESC""",
                (since,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_report_by_topic(self, subject_id: Optional[int] = None,
                             since_days: int = 30) -> List[Dict]:
        """Konu bazlı detay."""
        since = (date.today() - timedelta(days=since_days)).isoformat()
        conn = self._conn()
        try:
            where = "dq.log_date >= ?"
            args: tuple = (since,)
            if subject_id:
                where += " AND dq.subject_id=?"
                args = (since, subject_id)
            rows = conn.execute(
                f"""SELECT s.name as subject, s.icon,
                           t.title as topic,
                           SUM(dq.total_solved)  as total,
                           SUM(dq.correct_count) as correct,
                           SUM(dq.total_solved - dq.correct_count) as wrong,
                           ROUND(SUM(dq.correct_count)*100.0 /
                                 NULLIF(SUM(dq.total_solved),0), 1) as accuracy
                    FROM daily_questions dq
                    JOIN subjects s ON dq.subject_id=s.id
                    JOIN topics   t ON dq.topic_id=t.id
                    WHERE {where}
                    GROUP BY dq.topic_id
                    ORDER BY total DESC
                    LIMIT 50""",
                args,
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_report_trend(self, since_days: int = 14) -> List[Dict]:
        """Günlük doğruluk trendi — grafik için."""
        since = (date.today() - timedelta(days=since_days)).isoformat()
        conn = self._conn()
        try:
            rows = conn.execute(
                """SELECT log_date,
                          SUM(total_solved) as total,
                          SUM(correct_count) as correct,
                          ROUND(SUM(correct_count)*100.0 /
                                NULLIF(SUM(total_solved),0), 1) as accuracy
                   FROM daily_questions
                   WHERE log_date >= ?
                   GROUP BY log_date
                   ORDER BY log_date""",
                (since,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_report_summary_totals(self) -> Dict:
        """Tüm zamanların genel özeti."""
        conn = self._conn()
        try:
            r = conn.execute(
                """SELECT COUNT(DISTINCT log_date)          as active_days,
                          COALESCE(SUM(total_solved), 0)    as total_q,
                          COALESCE(SUM(correct_count), 0)   as correct_q,
                          ROUND(SUM(correct_count)*100.0 /
                                NULLIF(SUM(total_solved),0), 1) as accuracy,
                          COALESCE(MAX(total_solved_day),0) as best_day
                   FROM daily_questions,
                        (SELECT SUM(total_solved) as total_solved_day
                         FROM daily_questions GROUP BY log_date
                         ORDER BY total_solved_day DESC LIMIT 1)""",
            ).fetchone()
            streaks = self._calc_streak(conn)
        finally:
            conn.close()
        d = dict(r)
        d.update(streaks)
        return d

    def _calc_streak(self, conn) -> Dict:
        """Mevcut ve en uzun çalışma serisi."""
        rows = conn.execute(
            """SELECT DISTINCT log_date FROM daily_questions
               ORDER BY log_date DESC"""
        ).fetchall()
        dates = [date.fromisoformat(r["log_date"]) for r in rows]
        if not dates:
            return {"current_streak": 0, "longest_streak": 0}

        # Mevcut seri
        current = 0
        check = date.today()
        for d in dates:
            if d == check or d == check - timedelta(days=1):
                current += 1
                check = d
            else:
                break

        # En uzun seri
        longest = cur = 1
        for i in range(1, len(dates)):
            if (dates[i - 1] - dates[i]).days == 1:
                cur += 1
                longest = max(longest, cur)
            else:
                cur = 1
        return {"current_streak": current, "longest_streak": max(longest, current)}
