-- ============================================================
-- KPSS Takip Uygulaması - Veritabanı Şeması v2
-- ============================================================

CREATE TABLE IF NOT EXISTS subjects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    color_hex   TEXT DEFAULT '#6C8EBF',
    icon        TEXT DEFAULT '📚',
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS topics (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id      INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    parent_id       INTEGER REFERENCES topics(id) ON DELETE CASCADE,
    title           TEXT NOT NULL,
    order_index     INTEGER DEFAULT 0,
    is_completed    BOOLEAN DEFAULT 0,
    completed_at    DATETIME,
    review_1day     DATE,
    review_7day     DATE,
    review_30day    DATE,
    difficulty      INTEGER DEFAULT 3 CHECK(difficulty BETWEEN 1 AND 5),
    notes           TEXT,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pomodoro_sessions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id        INTEGER REFERENCES topics(id) ON DELETE SET NULL,
    subject_id      INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    started_at      DATETIME NOT NULL,
    ended_at        DATETIME,
    duration_min    INTEGER NOT NULL DEFAULT 25,
    actual_min      INTEGER,
    focus_score     INTEGER CHECK(focus_score BETWEEN 1 AND 5),
    session_type    TEXT DEFAULT 'work' CHECK(session_type IN ('work','short_break','long_break')),
    completed       BOOLEAN DEFAULT 0,
    notes           TEXT
);

CREATE TABLE IF NOT EXISTS daily_questions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    log_date        DATE NOT NULL DEFAULT (date('now')),
    subject_id      INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    topic_id        INTEGER NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
    total_solved    INTEGER NOT NULL DEFAULT 0,
    correct_count   INTEGER NOT NULL DEFAULT 0,
    err_knowledge   INTEGER DEFAULT 0,
    err_attention   INTEGER DEFAULT 0,
    err_time        INTEGER DEFAULT 0,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS daily_plans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_date       DATE NOT NULL UNIQUE,
    target_topics   TEXT DEFAULT '[]',
    target_questions INTEGER DEFAULT 0,
    target_study_min INTEGER DEFAULT 0,
    actual_topics   TEXT DEFAULT '[]',
    actual_questions INTEGER DEFAULT 0,
    actual_study_min INTEGER DEFAULT 0,
    notes           TEXT,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS activity_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    log_date        DATE NOT NULL UNIQUE,
    study_minutes   INTEGER DEFAULT 0,
    questions_solved INTEGER DEFAULT 0,
    topics_completed INTEGER DEFAULT 0,
    pomodoros_done  INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
    key     TEXT PRIMARY KEY,
    value   TEXT NOT NULL
);

INSERT OR IGNORE INTO settings VALUES
    ('theme',                'dark'),
    ('pomodoro_work_min',    '25'),
    ('pomodoro_short_min',   '5'),
    ('pomodoro_long_min',    '15'),
    ('pomodoros_per_set',    '4'),
    ('sound_enabled',        '1'),
    ('sound_volume',         '70'),
    ('exam_date',            '2026-06-28'),
    ('daily_question_target','100'),
    ('daily_study_target_min','300'),
    ('user_name',            ''),
    ('onboarding_done',      '0');

CREATE INDEX IF NOT EXISTS idx_topics_subject    ON topics(subject_id);
CREATE INDEX IF NOT EXISTS idx_topics_parent     ON topics(parent_id);
CREATE INDEX IF NOT EXISTS idx_pomodoro_date     ON pomodoro_sessions(started_at);
CREATE INDEX IF NOT EXISTS idx_questions_date    ON daily_questions(log_date);
CREATE INDEX IF NOT EXISTS idx_questions_topic   ON daily_questions(topic_id);
CREATE INDEX IF NOT EXISTS idx_activity_date     ON activity_log(log_date);
